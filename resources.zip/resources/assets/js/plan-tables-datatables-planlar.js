/**
 * DataTables Extensions (jquery)
 */

'use strict';

var densisyet = [];
var duzey = parseFloat(0);
var duzeys = parseFloat(0);
var d = new Date();
var ay = d.getMonth() + 1;
var yil = d.getFullYear();

$(function() {
  var asama = $('#asama').val(),
    iso900115varyok = $('#iso900115varyok').val(),
    iso1400115varyok = $('#iso1400115varyok').val(),
    iso2200018varyok = $('#iso2200018varyok').val(),
    iso4500118varyok = $('#iso4500118varyok').val(),
    iso5000118varyok = $('#iso5000118varyok').val(),
    iso27001varyok = $('#iso27001varyok').val(),
    helalvaryok = $('#helalvaryok').val(),
    oicsmiik6varyok = $('#oicsmiik6varyok').val(),
    oicsmiik9varyok = $('#oicsmiik9varyok').val(),
    oicsmiik171varyok = $('#oicsmiik171varyok').val(),
    oicsmiik23varyok = $('#oicsmiik23varyok').val(),
    oicsmiik24varyok = $('#oicsmiik24varyok').val();

  var dt_crm_planlar_table = $('.dt-dashboard-crm-planlar'),
    dt_ea_nace_table = $('.dt-ea-nace-kodlari'),
    dt_22000_table = $('.dt-22000-kategori'),
    dt_smiic_table = $('.dt-smiic-kategori'),
    dt_27001_table = $('.dt-27001-kategori'),
    dt_50001_table = $('.dt-50001-kategori'),
    dt_asama1_basdenetci_table = $('.dt-asama1-basdenetciler'),
    dt_asama1_denetci_table = $('.dt-asama1-denetciler'),
    dt_asama1_teknik_uzman_table = $('.dt-asama1-teknik-uzman'),
    dt_asama1_gozlemci_table = $('.dt-asama1-gozlemci'),
    dt_asama1_iku_table = $('.dt-asama1-iku'),
    dt_asama1_aday_denetci_table = $('.dt-asama1-aday-denetci'),
    dt_asama1_degerlendirici_table = $('.dt-asama1-degerlendirici'),
    dt_asama2_basdenetci_table = $('.dt-asama2-basdenetciler'),
    dt_asama2_denetci_table = $('.dt-asama2-denetciler'),
    dt_asama2_teknik_uzman_table = $('.dt-asama2-teknik-uzman'),
    dt_asama2_gozlemci_table = $('.dt-asama2-gozlemci'),
    dt_asama2_iku_table = $('.dt-asama2-iku'),
    dt_asama2_aday_denetci_table = $('.dt-asama2-aday-denetci'),
    dt_asama2_degerlendirici_table = $('.dt-asama2-degerlendirici'),
    dt_gozetim1_basdenetci_table = $('.dt-gozetim1-basdenetciler'),
    dt_gozetim1_denetci_table = $('.dt-gozetim1-denetciler'),
    dt_gozetim1_teknik_uzman_table = $('.dt-gozetim1-teknik-uzman'),
    dt_gozetim1_gozlemci_table = $('.dt-gozetim1-gozlemci'),
    dt_gozetim1_iku_table = $('.dt-gozetim1-iku'),
    dt_gozetim1_aday_denetci_table = $('.dt-gozetim1-aday-denetci'),
    dt_gozetim1_degerlendirici_table = $('.dt-gozetim1-degerlendirici'),
    dt_gozetim2_basdenetci_table = $('.dt-gozetim2-basdenetciler'),
    dt_gozetim2_denetci_table = $('.dt-gozetim2-denetciler'),
    dt_gozetim2_teknik_uzman_table = $('.dt-gozetim2-teknik-uzman'),
    dt_gozetim2_gozlemci_table = $('.dt-gozetim2-gozlemci'),
    dt_gozetim2_iku_table = $('.dt-gozetim2-iku'),
    dt_gozetim2_aday_denetci_table = $('.dt-gozetim2-aday-denetci'),
    dt_gozetim2_degerlendirici_table = $('.dt-gozetim2-degerlendirici'),
    dt_yb_basdenetci_table = $('.dt-yb-basdenetciler'),
    dt_yb_denetci_table = $('.dt-yb-denetciler'),
    dt_yb_teknik_uzman_table = $('.dt-yb-teknik-uzman'),
    dt_yb_gozlemci_table = $('.dt-yb-gozlemci'),
    dt_yb_iku_table = $('.dt-yb-iku'),
    dt_yb_aday_denetci_table = $('.dt-yb-aday-denetci'),
    dt_yb_degerlendirici_table = $('.dt-yb-degerlendirici'),
    dt_ot_basdenetci_table = $('.dt-ot-basdenetciler'),
    dt_ot_denetci_table = $('.dt-ot-denetciler'),
    dt_ot_teknik_uzman_table = $('.dt-ot-teknik-uzman'),
    dt_ot_gozlemci_table = $('.dt-ot-gozlemci'),
    dt_ot_iku_table = $('.dt-ot-iku'),
    dt_ot_aday_denetci_table = $('.dt-ot-aday-denetci'),
    dt_ot_degerlendirici_table = $('.dt-ot-degerlendirici'),
    tblbelgelifirmalarals05 = $('#tblbelgelifirmalarals05');

  $.extend($.fn.dataTable.ext.type.order, {
    "turkish-pre": function (d) {
      return d.replace(/ö/g, 'oe')
        .replace(/Ö/g, 'Oe')
        .replace(/ç/g, 'c')
        .replace(/Ç/g, 'C')
        .replace(/ş/g, 's')
        .replace(/Ş/g, 'S')
        .replace(/ğ/g, 'g')
        .replace(/Ğ/g, 'G')
        .replace(/ü/g, 'ue')
        .replace(/Ü/g, 'Ue')
        .replace(/ı/g, 'i')
        .replace(/İ/g, 'I');
    },
    "turkish-asc": function (a, b) {
      return ((a < b) ? -1 : ((a > b) ? 1 : 0));
    },
    "turkish-desc": function (a, b) {
      return ((a < b) ? 1 : ((a > b) ? -1 : 0));
    }
  });

  $.fn.dataTable.ext.search.push(
    function(settings, data, dataIndex) {
      var normalizedSearch = function(str) {
        return str.replace(/ö/g, 'oe')
          .replace(/Ö/g, 'Oe')
          .replace(/ç/g, 'c')
          .replace(/Ç/g, 'C')
          .replace(/ş/g, 's')
          .replace(/Ş/g, 'S')
          .replace(/ğ/g, 'g')
          .replace(/Ğ/g, 'G')
          .replace(/ü/g, 'ue')
          .replace(/Ü/g, 'Ue')
          .replace(/ı/g, 'i')
          .replace(/İ/g, 'I');
      };

      var searchTerm = normalizedSearch(settings.oPreviousSearch.sSearch);
      for (var i = 0; i < data.length; i++) {
        if (normalizedSearch(data[i]).includes(searchTerm)) {
          return true;
        }
      }
      return false;
    }
  );

  // FixedHeader
  // --------------------------------------------------------------------
  // dt_crm_planlar_table.DataTable.datetime('D.M.YYYY');
  if (dt_crm_planlar_table.length) {
    // Setup - add a text input to each footer cell
    $('.dt-dashboard-crm-planlar thead tr').clone(true).appendTo('.dt-dashboard-crm-planlar thead');
    $('.dt-dashboard-crm-planlar thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_crm_planlar.column(i).search() !== this.value) {
          dt_crm_planlar.column(i).search(this.value).draw();
        }
      });
    });

    var dt_crm_planlar = dt_crm_planlar_table.DataTable({
      ajax: planlarRoutePath,
      columns: [
        { data: '' },
        { data: 'planno' },
        { data: 'firmaadi' },
        { data: 'belgelendirileceksistemler' },
        { data: 'dentarihi' },
        { data: 'bitistarihi' },
        { data: 'danisman' },
        { data: 'belgedurum' }
      ],
      columnDefs: [
        {
          // Actions
          width: '4%',
          targets: 0,
          title: '#',
          orderable: false,
          searchable: false,
          render: function(data, type, full, meta) {
            return (
              '<div class="d-inline-block">' +
              '<a href="javascript:;" class="btn btn-sm btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="mdi mdi-dots-vertical"></i></a>' +
              '<div class="dropdown-menu dropdown-menu-end m-0">' +
              '<a href="' + myRoutes('basvuru', full['planno']) + '" class="dropdown-item" target="_blank">Başvuru bilgileri</a>' +
              '<a href="' + myRoutes('ilkplan', full['planno']) + '" class="dropdown-item" target="_blank">İlk Planlama</a>' +
              '<a href="' + myRoutes('ilkkarar', full['planno']) + '" class="dropdown-item" target="_blank">İlk Karar</a>' +
              '<div class="dropdown-divider"></div>' +
              '<a href="' + myRoutes('g1', full['planno']) + '" class="dropdown-item" target="_blank">1. Gözetim</a>' +
              '<a href="' + myRoutes('g1karar', full['planno']) + '" class="dropdown-item" target="_blank">G1 Karar</a>' +
              '<div class="dropdown-divider"></div>' +
              '<a href="' + myRoutes('g2', full['planno']) + '" class="dropdown-item" target="_blank">2. Gözetim</a>' +
              '<a href="' + myRoutes('g2karar', full['planno']) + '" class="dropdown-item" target="_blank">G2 Karar</a>' +
              '<div class="dropdown-divider"></div>' +
              '<a href="' + myRoutes('yb', full['planno']) + '" class="dropdown-item" target="_blank">Yb</a>' +
              '<a href="' + myRoutes('ybkarar', full['planno']) + '" class="dropdown-item" target="_blank">Yb Karar</a>' +
              '<div class="dropdown-divider"></div>' +
              '<a href="' + myRoutes('ozel', full['planno']) + '" class="dropdown-item" target="_blank">Özel</a>' +
              '<a href="' + myRoutes('ozelkarar', full['planno']) + '" class="dropdown-item" target="_blank">Özel Karar</a>' +
              '<div class="dropdown-divider"></div>' +
              '<a href="' + myRoutes('sertifika', full['planno']) + '" class="dropdown-item text-success delete-record" target="_blank">Sertifika</a>' +
              '<div class="dropdown-divider"></div>' +
              '<a href="javascript:;" class="dropdown-item text-danger delete-record">Plan Sil</a>' +
              '</div>' +
              '</div>'
            );
          }
        },
        {
          // müşteri no
          width: '6%',
          targets: 1,
          orderable: true,
          visible: true,
          render: function(data, type, full, meta) {
            return (
              '<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#backDropModal">' +
              full['planno'] +
              ' </button>'
            );
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '40%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $user_img = full['planno'],
              $name = full['firmaadi'],
              $addrr = full['firmaadresi'],
              $kapsam = full['belgelendirmekapsami'],
              $iso9 = parseInt(full['iso900115varyok']),
              $iso14 = parseInt(full['iso1400115varyok']),
              $iso45 = parseInt(full['iso4500118varyok']),
              $iso27 = parseInt(full['iso27001varyok']),
              $iso51 = parseInt(full['iso5000118varyok']),
              $iso22 = parseInt(full['iso2200018varyok']),
              $smiic = parseInt(full['helalvaryok']),
              $smiic6 = parseInt(full['oicsmiik6varyok']),
              $smiic9 = parseInt(full['oicsmiik9varyok']),
              $smiic171 = parseInt(full['oicsmiik171varyok']),
              $smiic24 = parseInt(full['oicsmiik24varyok']),
              $dtipi = full['dtipi'];
            var $kodlar = '';
            $kodlar = ($iso9 === 1 || $iso14 === 1 || $iso45 === 1) ? full['eakodu'] + '|' + full['nacekodu'] : '';
            $kodlar += ($iso22 === 1) ? '@' + full['kategori22'] : '';
            $kodlar += ($smiic === 1 || $smiic6 === 1 || $smiic9 === 1 || $smiic171 === 1 || $smiic24 === 1) ? 'ß' + full['kategorioic'] : '';
            $kodlar += ($iso51 === 1) ? 'Æ' + full['teknikalanenys'] : '';
            $kodlar += ($iso27 === 1) ? '€' + full['kategoribgys'] : '';
            // console.log($kodlar);
            // For Avatar badge
            var stateNum = Math.floor(Math.random() * 6);
            var states = ['success', 'danger', 'warning', 'info', 'dark', 'primary', 'secondary'];
            var $state = states[stateNum];
            // var $initials = $name.match(/\b\w/g) || [];
            // $initials = (($initials.shift() || '') + ($initials.pop() || '')).toUpperCase();
            var $output = '<span class="avatar-initial rounded-circle bg-label-' + $state + '">' + $dtipi + '</span>';
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="avatar-wrapper">' +
              '<div class="avatar me-2">' +
              $output +
              '</div>' +
              '</div>' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap"><a href="' + myRoutes(full['asama'], full['planno']) + '" target="_blank">' +
              $name +
              '</a></span>' +
              '<small class="emp_post text-truncate text-wrap">' +
              $addrr +
              '</small>' +
              '<small class="emp_post text-truncate text-wrap text-danger">' +
              $kapsam +
              '</small>' +
              '<small class="emp_post text-truncate text-wrap text-success">' +
              $kodlar +
              '</small>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // standartlar
          width: '20%',
          targets: 3
        },
        {
          // denetim tarihi
          width: '8%',
          targets: 4
        },
        {
          // belge geçerlilik tarihi
          width: '8%',
          targets: 5,
          render: dt_crm_planlar_table.DataTable.render.date()
        },
        {
          // kimden
          width: '6%',
          targets: 6
        },
        {
          // durum
          width: '10%',
          targets: 7,
          render: function(data, type, full, meta) {
            var $status_name = full['belgedurum'];
            // console.log(full['planno'] + " => " + $status_name);
            var $status_number = ($status_name === 'devam') ? 1 : ($status_name === 'aski') ? 2 : ($status_name === 'iptal') ? 3 : 4;
            var $status = {
              1: { title: 'Devam', class: 'bg-label-success' },
              2: { title: 'Askı', class: ' bg-label-warning' },
              3: { title: 'İptal', class: ' bg-label-danger' },
              4: { title: '  -  ', class: ' bg-label-primary' }
            };
            if (typeof $status[$status_number] === 'undefined') {
              return data;
            }
            return (
              '<span class="badge rounded-pill ' +
              $status[$status_number].class +
              '">' +
              $status[$status_number].title +
              '</span>'
            );
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'desc']],
      dom:
        '<"row mx-2"' +
        '<"col-md-2"<"me-3"l>>' +
        '<"col-md-10"<"dt-action-buttons text-xl-end text-lg-start text-md-end text-start d-flex align-items-center justify-content-end flex-md-row flex-column mb-3 mb-md-0 gap-3"fB>>' +
        '>t' +
        '<"row mx-2"' +
        '<"col-sm-12 col-md-6"i>' +
        '<"col-sm-12 col-md-6"p>' +
        '>',
      language: {
        "info": "_TOTAL_ kayıttan _START_ - _END_ arasındaki kayıtlar gösteriliyor",
        "infoEmpty": "Kayıt yok",
        "infoFiltered": "(_MAX_ kayıt içerisinden bulunan)",
        "infoThousands": ".",
        "lengthMenu": "Sayfada _MENU_ kayıt göster",
        "loadingRecords": "Yükleniyor...",
        "processing": "İşleniyor...",
        "search": "",
        "zeroRecords": "Eşleşen kayıt bulunamadı",
        "paginate": {
          "first": "İlk",
          "last": "Son",
          "next": "Sonraki",
          "previous": "Önceki"
        },
        "aria": {
          "sortAscending": ": artan sütun sıralamasını aktifleştir",
          "sortDescending": ": azalan sütun sıralamasını aktifleştir"
        },
        "select": {
          "rows": {
            "_": "%d kayıt seçildi",
            "1": "1 kayıt seçildi"
          },
          "cells": {
            "1": "1 hücre seçildi",
            "_": "%d hücre seçildi"
          },
          "columns": {
            "1": "1 sütun seçildi",
            "_": "%d sütun seçildi"
          }
        },
        "autoFill": {
          "cancel": "İptal",
          "fillHorizontal": "Hücreleri yatay olarak doldur",
          "fillVertical": "Hücreleri dikey olarak doldur",
          "fill": "Bütün hücreleri <i>%d<\/i> ile doldur",
          "info": "Detayı"
        },
        "buttons": {
          "collection": "Koleksiyon <span class=\"ui-button-icon-primary ui-icon ui-icon-triangle-1-s\"><\/span>",
          "colvis": "Sütun görünürlüğü",
          "colvisRestore": "Görünürlüğü eski haline getir",
          "copySuccess": {
            "1": "1 satır panoya kopyalandı",
            "_": "%ds satır panoya kopyalandı"
          },
          "copyTitle": "Panoya kopyala",
          "csv": "CSV",
          "excel": "Excel",
          "pageLength": {
            "-1": "Bütün satırları göster",
            "_": "%d satır göster",
            "1": "1 Satır Göster"
          },
          "pdf": "PDF",
          "print": "Yazdır",
          "copy": "Kopyala",
          "copyKeys": "Tablodaki veriyi kopyalamak için CTRL veya u2318 + C tuşlarına basınız. İptal etmek için bu mesaja tıklayın veya escape tuşuna basın.",
          "createState": "Şuanki Görünümü Kaydet",
          "removeAllStates": "Tüm Görünümleri Sil",
          "removeState": "Aktif Görünümü Sil",
          "renameState": "Aktif Görünümün Adını Değiştir",
          "savedStates": "Kaydedilmiş Görünümler",
          "stateRestore": "Görünüm -&gt; %d",
          "updateState": "Aktif Görünümün Güncelle"
        },
        "searchBuilder": {
          "add": "Koşul Ekle",
          "button": {
            "0": "Arama Oluşturucu",
            "_": "Arama Oluşturucu (%d)"
          },
          "condition": "Koşul",
          "conditions": {
            "date": {
              "after": "Sonra",
              "before": "Önce",
              "between": "Arasında",
              "empty": "Boş",
              "equals": "Eşittir",
              "not": "Değildir",
              "notBetween": "Dışında",
              "notEmpty": "Dolu"
            },
            "number": {
              "between": "Arasında",
              "empty": "Boş",
              "equals": "Eşittir",
              "gt": "Büyüktür",
              "gte": "Büyük eşittir",
              "lt": "Küçüktür",
              "lte": "Küçük eşittir",
              "not": "Değildir",
              "notBetween": "Dışında",
              "notEmpty": "Dolu"
            },
            "string": {
              "contains": "İçerir",
              "empty": "Boş",
              "endsWith": "İle biter",
              "equals": "Eşittir",
              "not": "Değildir",
              "notEmpty": "Dolu",
              "startsWith": "İle başlar",
              "notContains": "İçermeyen",
              "notStartsWith": "Başlamayan",
              "notEndsWith": "Bitmeyen"
            },
            "array": {
              "contains": "İçerir",
              "empty": "Boş",
              "equals": "Eşittir",
              "not": "Değildir",
              "notEmpty": "Dolu",
              "without": "Hariç"
            }
          },
          "data": "Veri",
          "deleteTitle": "Filtreleme kuralını silin",
          "leftTitle": "Kriteri dışarı çıkart",
          "logicAnd": "ve",
          "logicOr": "veya",
          "rightTitle": "Kriteri içeri al",
          "title": {
            "0": "Arama Oluşturucu",
            "_": "Arama Oluşturucu (%d)"
          },
          "value": "Değer",
          "clearAll": "Filtreleri Temizle"
        },
        "searchPanes": {
          "clearMessage": "Hepsini Temizle",
          "collapse": {
            "0": "Arama Bölmesi",
            "_": "Arama Bölmesi (%d)"
          },
          "count": "{total}",
          "countFiltered": "{shown}\/{total}",
          "emptyPanes": "Arama Bölmesi yok",
          "loadMessage": "Arama Bölmeleri yükleniyor ...",
          "title": "Etkin filtreler - %d",
          "showMessage": "Tümünü Göster",
          "collapseMessage": "Tümünü Gizle"
        },
        "thousands": ".",
        "datetime": {
          "amPm": [
            "öö",
            "ös"
          ],
          "hours": "Saat",
          "minutes": "Dakika",
          "next": "Sonraki",
          "previous": "Önceki",
          "seconds": "Saniye",
          "unknown": "Bilinmeyen",
          "weekdays": {
            "6": "Paz",
            "5": "Cmt",
            "4": "Cum",
            "3": "Per",
            "2": "Çar",
            "1": "Sal",
            "0": "Pzt"
          },
          "months": {
            "9": "Ekim",
            "8": "Eylül",
            "7": "Ağustos",
            "6": "Temmuz",
            "5": "Haziran",
            "4": "Mayıs",
            "3": "Nisan",
            "2": "Mart",
            "11": "Aralık",
            "10": "Kasım",
            "1": "Şubat",
            "0": "Ocak"
          }
        },
        "decimal": ",",
        "editor": {
          "close": "Kapat",
          "create": {
            "button": "Yeni",
            "submit": "Kaydet",
            "title": "Yeni kayıt oluştur"
          },
          "edit": {
            "button": "Düzenle",
            "submit": "Güncelle",
            "title": "Kaydı düzenle"
          },
          "error": {
            "system": "Bir sistem hatası oluştu (Ayrıntılı bilgi)"
          },
          "multi": {
            "info": "Seçili kayıtlar bu alanda farklı değerler içeriyor. Seçili kayıtların hepsinde bu alana aynı değeri atamak için buraya tıklayın; aksi halde her kayıt bu alanda kendi değerini koruyacak.",
            "noMulti": "Bu alan bir grup olarak değil ancak tekil olarak düzenlenebilir.",
            "restore": "Değişiklikleri geri al",
            "title": "Çoklu değer"
          },
          "remove": {
            "button": "Sil",
            "confirm": {
              "_": "%d adet kaydı silmek istediğinize emin misiniz?",
              "1": "Bu kaydı silmek istediğinizden emin misiniz?"
            },
            "submit": "Sil",
            "title": "Kayıtları sil"
          }
        },
        "stateRestore": {
          "creationModal": {
            "button": "Kaydet",
            "columns": {
              "search": "Kolon Araması",
              "visible": "Kolon Görünümü"
            },
            "name": "Görünüm İsmi",
            "order": "Sıralama",
            "paging": "Sayfalama",
            "scroller": "Kaydırma (Scrool)",
            "search": "",
            "searchBuilder": "Arama Oluşturucu",
            "select": "Seçimler",
            "title": "Yeni Görünüm Oluştur",
            "toggleLabel": "Kaydedilecek Olanlar"
          },
          "duplicateError": "Bu Görünüm Daha Önce Tanımlanmış",
          "emptyError": "Görünüm Boş Olamaz",
          "emptyStates": "Herhangi Bir Görünüm Yok",
          "removeJoiner": "ve",
          "removeSubmit": "Sil",
          "removeTitle": "Görünüm Sil",
          "renameButton": "Değiştir",
          "renameLabel": "Görünüme Yeni İsim Ver -&gt; %s:",
          "renameTitle": "Görünüm İsmini Değiştir",
          "removeConfirm": "Görünümü silmek istediğinize emin misiniz?",
          "removeError": "Görünüm silinemedi"
        },
        "emptyTable": "Tabloda veri bulunmuyor",
        "searchPlaceholder": "Arayın...",
        "infoPostFix": " "
      },
      // Buttons with Dropdown
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-secondary dropdown-toggle me-3 waves-effect waves-light',
          text: '<i class="mdi mdi-export-variant me-1"></i> <span class="d-none d-sm-inline-block">Dışarı Aktar</span>',
          buttons: [
            {
              extend: 'excelHtml5',
              autoFilter: true,
              text: '<i class="mdi mdi-file-excel-outline me-1"></i>Excel',
              className: 'dropdown-item',
              exportOptions: {
                columns: [1, 2, 3, 4, 5, 6, 7],
                // prevent avatar to be display
                format: {
                  body: function (inner, coldex, rowdex) {
                    if (inner.length <= 0) return inner;
                    var el = $.parseHTML(inner);
                    var result = '';
                    $.each(el, function (index, item) {
                      if (item.classList !== undefined && item.classList.contains('user-name')) {
                        result = result + item.lastChild.firstChild.textContent;
                      } else if (item.innerText === undefined) {
                        result = result + item.textContent;
                      } else result = result + item.innerText;
                    });
                    return result;
                  }
                }
              }
            },
            {
              extend: 'pdf',
              text: '<i class="mdi mdi-file-pdf-box me-1"></i>Pdf',
              className: 'dropdown-item',
              exportOptions: {
                columns: [1, 2, 3, 4, 5],
                // prevent avatar to be display
                format: {
                  body: function (inner, coldex, rowdex) {
                    if (inner.length <= 0) return inner;
                    var el = $.parseHTML(inner);
                    var result = '';
                    $.each(el, function (index, item) {
                      if (item.classList !== undefined && item.classList.contains('user-name')) {
                        result = result + item.lastChild.firstChild.textContent;
                      } else if (item.innerText === undefined) {
                        result = result + item.textContent;
                      } else result = result + item.innerText;
                    });
                    return result;
                  }
                }
              }
            }
          ]
        }
      ],
      displayLength: 10,
      lengthMenu: [7, 10, 25, 50, 75, 100],
      scrollX: true,
      responsive: {
        details: {
          display: $.fn.dataTable.Responsive.display.modal({
            header: function(row) {
              var data = row.data();
              return 'Details of ' + data['firmaadi'];
            }
          }),
          type: 'column',
          renderer: function(api, rowIdx, columns) {
            var data = $.map(columns, function(col, i) {
              return col.title !== '' // ? Do not show row in modal popup if title is blank (for check box)
                ? '<tr data-dt-row="' +
                col.rowIndex +
                '" data-dt-column="' +
                col.columnIndex +
                '">' +
                '<td>' +
                col.title +
                ':' +
                '</td> ' +
                '<td class="emp_post text-truncate text-wrap">' +
                col.data +
                '</td>' +
                '</tr>'
                : '';
            }).join('');

            return data ? $('<table class="table"/><tbody />').append(data) : false;
          }
        }
      }
    });

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      var navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_crm_planlar).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_crm_planlar);
    }

  }

  if (dt_ea_nace_table.length) {
    // Setup - add a text input to each footer cell
    $('.dt-ea-nace-kodlari thead tr').clone(true).appendTo('.dt-ea-nace-kodlari thead');
    $('.dt-ea-nace-kodlari thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_filter_en.column(i).search() !== this.value) {
          dt_filter_en.column(i).search(this.value).draw();
        }
      });
    });

    var dt_filter_en = dt_ea_nace_table.DataTable({
      ajax: eanaceRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'kk9' },
        { data: 'kk14' },
        { data: 'kk45' },
        { data: 'ea' },
        { data: 'nace' },
        { data: 'aciklama' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          render: function(data, type, full, meta) {
            var chkvalue = full['id'] + '|' + full['kk9'] + '|' + full['kk14'] + '|' + full['kk45'] + '|' + full['ea'] + '|' + full['nace'];
            return (full['kk9'] !== '') ? '<input type="checkbox" id="dt_ea_nace_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setEaNaceKategori(\'' + chkvalue + '\')" class="dt-checkboxes form-check-input">' : '';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          targets: 1,
          searchable: false,
          orderable: true,
          width: '10px'
        },
        {
          targets: 2,
          searchable: false,
          orderable: false,
          width: '10px'
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_filter_en.columns.adjust().draw();
  }

  if (dt_22000_table.length) {
    // Setup - add a text input to each footer cell
    $('.dt-22000-kategori thead tr').clone(true).appendTo('.dt-22000-kategori thead');
    $('.dt-22000-kategori thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_filter22.column(i).search() !== this.value) {
          dt_filter22.column(i).search(this.value).draw();
        }
      });
    });

    var dt_filter22 = dt_22000_table.DataTable({
      ajax: cat22RoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'kategori' },
        { data: 'baslik' },
        { data: 'aciklama' },
        { data: 'bb' },
        { data: 'cc' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['id'] + '|' + full['kategori'] + '|' + full['bb'] + '|' + full['cc'];
            return '<input type="checkbox" id="dt_22000_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setEaNaceKategori(\'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          targets: 5,
          visible: true
        },
        {
          targets: 6,
          visible: true
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_filter22.columns.adjust().draw();
  }

  if (dt_smiic_table.length) {
    // Setup - add a text input to each footer cell
    $('.dt-smiic-kategori thead tr').clone(true).appendTo('.dt-smiic-kategori thead');
    $('.dt-smiic-kategori thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_smiic.column(i).search() !== this.value) {
          dt_smiic.column(i).search(this.value).draw();
        }
      });
    });

    var dt_smiic = dt_smiic_table.DataTable({
      ajax: catSmiicRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'kategori' },
        { data: 'baslik' },
        { data: 'aciklama' },
        { data: 'ornekler' },
        { data: 'bb' },
        { data: 'cc' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['id'] + '|' + full['kategori'] + '|' + full['bb'] + '|' + full['cc'];
            return '<input type="checkbox" id="dt_smiic_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setEaNaceKategori(\'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          targets: 6,
          visible: true
        },
        {
          targets: 7,
          visible: true
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_smiic.columns.adjust().draw();
  }

  if (dt_27001_table.length) {
    // Setup - add a text input to each footer cell
    $('.dt-27001-kategori thead tr').clone(true).appendTo('.dt-27001-kategori thead');
    $('.dt-27001-kategori thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_27001.column(i).search() !== this.value) {
          dt_27001.column(i).search(this.value).draw();
        }
      });
    });

    var dt_27001 = dt_27001_table.DataTable({
      ajax: cat27001RoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'sektorgrubu' },
        { data: 'sektor' },
        { data: 'teknikalan' },
        { data: 'teknikalankodu' },
        { data: 'teknikalangrubu' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['id'] + '|' + full['teknikalankodu'] + '|' + full['teknikalangrubu'];
            return '<input type="checkbox" id="dt_27001_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setEaNaceKategori(\'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          targets: 6,
          visible: true
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_27001.columns.adjust().draw();
  }

  if (dt_50001_table.length) {
    // Setup - add a text input to each footer cell
    $('.dt-50001-kategori thead tr').clone(true).appendTo('.dt-50001-kategori thead');
    $('.dt-50001-kategori thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_50001.column(i).search() !== this.value) {
          dt_50001.column(i).search(this.value).draw();
        }
      });
    });

    var dt_50001 = dt_50001_table.DataTable({
      ajax: cat50001RoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'teknikalan' },
        { data: 'aciklama' },
        { data: 'teknikalangrubu' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['id'] + '|' + full['teknikalan'] + '|' + full['teknikalangrubu'];
            return '<input type="checkbox" id="dt_50001_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setEaNaceKategori(\'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_50001.columns.adjust().draw();
  }

  if (dt_asama1_basdenetci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-basdenetciler thead tr').clone(true).appendTo('.dt-asama1-basdenetciler thead');
    $('.dt-asama1-basdenetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_basdenetci.column(i).search() !== this.value) {
          dt_asama1_basdenetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_basdenetci = dt_asama1_basdenetci_table.DataTable({
      ajax: dtBasdenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci', type: 'turkish' },
        { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="radio" id="dt_asama1_basdenetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setBasdenetci(\'bd1\', \'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="radio" class="form-check-input">'
          }
        },
        {
          targets: 1,
          visible: false,
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[2, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'single'
      }
    });
    dt_asama1_basdenetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_asama1_basdenetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_asama1_basdenetci);
    }
  }

  if (dt_asama1_denetci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-denetciler thead tr').clone(true).appendTo('.dt-asama1-denetciler thead');
    $('.dt-asama1-denetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_denetci.column(i).search() !== this.value) {
          dt_asama1_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_denetci = dt_asama1_denetci_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama1_denetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'d1\', \'asama1-denetciler\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama1_denetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_asama1_denetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_asama1_denetci);
    }
  }

  if (dt_asama1_teknik_uzman_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-teknik-uzman thead tr').clone(true).appendTo('.dt-asama1-teknik-uzman thead');
    $('.dt-asama1-teknik-uzman thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_teknik_uzman.column(i).search() !== this.value) {
          dt_asama1_teknik_uzman.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_teknik_uzman = dt_asama1_teknik_uzman_table.DataTable({
      ajax: dtTeknikUzmanRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama1_teknik_uzman' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'tu1\', \'asama1-teknik-uzman\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama1_teknik_uzman.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama1_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama1_teknik_uzman);
    // }
  }

  if (dt_asama1_gozlemci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-gozlemci thead tr').clone(true).appendTo('.dt-asama1-gozlemci thead');
    $('.dt-asama1-gozlemci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_gozlemci.column(i).search() !== this.value) {
          dt_asama1_gozlemci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_gozlemci = dt_asama1_gozlemci_table.DataTable({
      ajax: dtGozlemciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama1_gozlemci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'g1\', \'asama1-gozlemci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama1_gozlemci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_asama1_teknik_uzman).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_asama1_teknik_uzman);
    }
  }

  if (dt_asama1_iku_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-iku thead tr').clone(true).appendTo('.dt-asama1-iku thead');
    $('.dt-asama1-iku thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_iku.column(i).search() !== this.value) {
          dt_asama1_iku.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_iku = dt_asama1_iku_table.DataTable({
      ajax: dtIkuRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama1_iku' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'iku1\', \'asama1-iku\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama1_iku.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama1_iku).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama1_iku);
    // }
  }

  if (dt_asama1_aday_denetci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-aday-denetci thead tr').clone(true).appendTo('.dt-asama1-aday-denetci thead');
    $('.dt-asama1-aday-denetci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_aday_denetci.column(i).search() !== this.value) {
          dt_asama1_aday_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_aday_denetci = dt_asama1_aday_denetci_table.DataTable({
      ajax: dtAdayDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama1_aday_denetci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ad1\', \'asama1-aday-denetci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama1_aday_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama1_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama1_aday_denetci);
    // }
  }

  if (dt_asama1_degerlendirici_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama1-degerlendirici thead tr').clone(true).appendTo('.dt-asama1-degerlendirici thead');
    $('.dt-asama1-degerlendirici thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama1_degerlendirici.column(i).search() !== this.value) {
          dt_asama1_degerlendirici.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama1_degerlendirici = dt_asama1_degerlendirici_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama1_degerlendirici' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'sid1\', \'asama1-degerlendirici\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama1_degerlendirici.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama1_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama1_aday_denetci);
    // }
  }

  if (dt_asama2_basdenetci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-basdenetciler thead tr').clone(true).appendTo('.dt-asama2-basdenetciler thead');
    $('.dt-asama2-basdenetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_basdenetci.column(i).search() !== this.value) {
          dt_asama2_basdenetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_basdenetci = dt_asama2_basdenetci_table.DataTable({
      ajax: dtBasdenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="radio" id="dt_asama2_basdenetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setBasdenetci(\'bd2\', \'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="radio" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'single'
      }
    });
    dt_asama2_basdenetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_asama2_basdenetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_asama2_basdenetci);
    }
  }

  if (dt_asama2_denetci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-denetciler thead tr').clone(true).appendTo('.dt-asama2-denetciler thead');
    $('.dt-asama2-denetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_denetci.column(i).search() !== this.value) {
          dt_asama2_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_denetci = dt_asama2_denetci_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama2_denetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'d2\', \'asama2-denetciler\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama2_denetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_asama2_denetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_asama2_denetci);
    }
  }

  if (dt_asama2_teknik_uzman_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-teknik-uzman thead tr').clone(true).appendTo('.dt-asama2-teknik-uzman thead');
    $('.dt-asama2-teknik-uzman thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_teknik_uzman.column(i).search() !== this.value) {
          dt_asama2_teknik_uzman.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_teknik_uzman = dt_asama2_teknik_uzman_table.DataTable({
      ajax: dtTeknikUzmanRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama2_teknik_uzman' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'tu2\', \'asama2-teknik-uzman\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama2_teknik_uzman.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama2_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama2_teknik_uzman);
    // }
  }

  if (dt_asama2_gozlemci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-gozlemci thead tr').clone(true).appendTo('.dt-asama2-gozlemci thead');
    $('.dt-asama2-gozlemci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_gozlemci.column(i).search() !== this.value) {
          dt_asama2_gozlemci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_gozlemci = dt_asama2_gozlemci_table.DataTable({
      ajax: dtGozlemciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama2_gozlemci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'g2\', \'asama2-gozlemci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama2_gozlemci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_asama2_teknik_uzman).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_asama2_teknik_uzman);
    }
  }

  if (dt_asama2_iku_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-iku thead tr').clone(true).appendTo('.dt-asama2-iku thead');
    $('.dt-asama2-iku thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_iku.column(i).search() !== this.value) {
          dt_asama2_iku.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_iku = dt_asama2_iku_table.DataTable({
      ajax: dtIkuRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama2_iku' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'iku2\', \'asama2-iku\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama2_iku.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama2_iku).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama2_iku);
    // }
  }

  if (dt_asama2_aday_denetci_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-aday-denetci thead tr').clone(true).appendTo('.dt-asama2-aday-denetci thead');
    $('.dt-asama2-aday-denetci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_aday_denetci.column(i).search() !== this.value) {
          dt_asama2_aday_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_aday_denetci = dt_asama2_aday_denetci_table.DataTable({
      ajax: dtAdayDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama2_aday_denetci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ad2\', \'asama2-aday-denetci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama2_aday_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama2_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama2_aday_denetci);
    // }
  }

  if (dt_asama2_degerlendirici_table.length && asama === 'ilkplan') {
    // Setup - add a text input to each footer cell
    $('.dt-asama2-degerlendirici thead tr').clone(true).appendTo('.dt-asama2-degerlendirici thead');
    $('.dt-asama2-degerlendirici thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_asama2_degerlendirici.column(i).search() !== this.value) {
          dt_asama2_degerlendirici.column(i).search(this.value).draw();
        }
      });
    });

    var dt_asama2_degerlendirici = dt_asama2_degerlendirici_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_asama2_degerlendirici' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ad2\', \'asama2-degerlendirici\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_asama2_degerlendirici.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_asama2_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_asama2_aday_denetci);
    // }
  }

  if (dt_gozetim1_basdenetci_table.length && asama === 'g1') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim1-basdenetciler thead tr').clone(true).appendTo('.dt-gozetim1-basdenetciler thead');
    $('.dt-gozetim1-basdenetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim1_basdenetci.column(i).search() !== this.value) {
          dt_gozetim1_basdenetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim1_basdenetci = dt_gozetim1_basdenetci_table.DataTable({
      ajax: dtBasdenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="radio" id="dt_gozetim1_basdenetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setBasdenetci(\'gbd1\', \'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="radio" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'single'
      }
    });
    dt_gozetim1_basdenetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_gozetim1_basdenetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_gozetim1_basdenetci);
    }
  }

  if (dt_gozetim1_denetci_table.length && asama === 'g1') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim1-denetciler thead tr').clone(true).appendTo('.dt-gozetim1-denetciler thead');
    $('.dt-gozetim1-denetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim1_denetci.column(i).search() !== this.value) {
          dt_gozetim1_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim1_denetci = dt_gozetim1_denetci_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim1_denetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gd1\', \'gozetim1-denetciler\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim1_denetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_gozetim1_denetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_gozetim1_denetci);
    }
  }

  if (dt_gozetim1_teknik_uzman_table.length && asama === 'g1') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim1-teknik-uzman thead tr').clone(true).appendTo('.dt-gozetim1-teknik-uzman thead');
    $('.dt-gozetim1-teknik-uzman thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim1_teknik_uzman.column(i).search() !== this.value) {
          dt_gozetim1_teknik_uzman.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim1_teknik_uzman = dt_gozetim1_teknik_uzman_table.DataTable({
      ajax: dtTeknikUzmanRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim1_teknik_uzman' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gtu1\', \'gozetim1-teknik-uzman\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim1_teknik_uzman.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_gozetim1_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_gozetim1_teknik_uzman);
    // }
  }

  if (dt_gozetim1_gozlemci_table.length && asama === 'g1') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim1-gozlemci thead tr').clone(true).appendTo('.dt-gozetim1-gozlemci thead');
    $('.dt-gozetim1-gozlemci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim1_gozlemci.column(i).search() !== this.value) {
          dt_gozetim1_gozlemci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim1_gozlemci = dt_gozetim1_gozlemci_table.DataTable({
      ajax: dtGozlemciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim1_gozlemci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gg1\', \'gozetim1-gozlemci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim1_gozlemci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_gozetim1_teknik_uzman).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_gozetim1_teknik_uzman);
    }
  }

  if (dt_gozetim1_iku_table.length && asama === 'g1') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim1-iku thead tr').clone(true).appendTo('.dt-gozetim1-iku thead');
    $('.dt-gozetim1-iku thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim1_iku.column(i).search() !== this.value) {
          dt_gozetim1_iku.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim1_iku = dt_gozetim1_iku_table.DataTable({
      ajax: dtIkuRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim1_iku' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'giku1\', \'gozetim1-iku\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim1_iku.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_gozetim1_iku).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_gozetim1_iku);
    // }
  }

  if (dt_gozetim1_aday_denetci_table.length && asama === 'g1') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim1-aday-denetci thead tr').clone(true).appendTo('.dt-gozetim1-aday-denetci thead');
    $('.dt-gozetim1-aday-denetci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim1_aday_denetci.column(i).search() !== this.value) {
          dt_gozetim1_aday_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim1_aday_denetci = dt_gozetim1_aday_denetci_table.DataTable({
      ajax: dtAdayDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim1_aday_denetci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gad1\', \'gozetim1-aday-denetci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim1_aday_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_gozetim1_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_gozetim1_aday_denetci);
    // }
  }

  if (dt_gozetim2_basdenetci_table.length && asama === 'g2') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim2-basdenetciler thead tr').clone(true).appendTo('.dt-gozetim2-basdenetciler thead');
    $('.dt-gozetim2-basdenetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim2_basdenetci.column(i).search() !== this.value) {
          dt_gozetim2_basdenetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim2_basdenetci = dt_gozetim2_basdenetci_table.DataTable({
      ajax: dtBasdenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="radio" id="dt_gozetim2_basdenetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setBasdenetci(\'gbd2\', \'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="radio" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'single'
      }
    });
    dt_gozetim2_basdenetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_gozetim2_basdenetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_gozetim2_basdenetci);
    }
  }

  if (dt_gozetim2_denetci_table.length && asama === 'g2') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim2-denetciler thead tr').clone(true).appendTo('.dt-gozetim2-denetciler thead');
    $('.dt-gozetim2-denetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim2_denetci.column(i).search() !== this.value) {
          dt_gozetim2_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim2_denetci = dt_gozetim2_denetci_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim2_denetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gd2\', \'gozetim2-denetciler\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim2_denetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_gozetim2_denetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_gozetim2_denetci);
    }
  }

  if (dt_gozetim2_teknik_uzman_table.length && asama === 'g2') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim2-teknik-uzman thead tr').clone(true).appendTo('.dt-gozetim2-teknik-uzman thead');
    $('.dt-gozetim2-teknik-uzman thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim2_teknik_uzman.column(i).search() !== this.value) {
          dt_gozetim2_teknik_uzman.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim2_teknik_uzman = dt_gozetim2_teknik_uzman_table.DataTable({
      ajax: dtTeknikUzmanRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim2_teknik_uzman' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gtu2\', \'gozetim2-teknik-uzman\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim2_teknik_uzman.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_gozetim2_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_gozetim2_teknik_uzman);
    // }
  }

  if (dt_gozetim2_gozlemci_table.length && asama === 'g2') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim2-gozlemci thead tr').clone(true).appendTo('.dt-gozetim2-gozlemci thead');
    $('.dt-gozetim2-gozlemci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim2_gozlemci.column(i).search() !== this.value) {
          dt_gozetim2_gozlemci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim2_gozlemci = dt_gozetim2_gozlemci_table.DataTable({
      ajax: dtGozlemciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim2_gozlemci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gg2\', \'gozetim2-gozlemci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim2_gozlemci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_gozetim2_teknik_uzman).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_gozetim2_teknik_uzman);
    }
  }

  if (dt_gozetim2_iku_table.length && asama === 'g2') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim2-iku thead tr').clone(true).appendTo('.dt-gozetim2-iku thead');
    $('.dt-gozetim2-iku thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim2_iku.column(i).search() !== this.value) {
          dt_gozetim2_iku.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim2_iku = dt_gozetim2_iku_table.DataTable({
      ajax: dtIkuRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim2_iku' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'giku2\', \'gozetim2-iku\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim2_iku.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_gozetim2_iku).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_gozetim2_iku);
    // }
  }

  if (dt_gozetim2_aday_denetci_table.length && asama === 'g2') {
    // Setup - add a text input to each footer cell
    $('.dt-gozetim2-aday-denetci thead tr').clone(true).appendTo('.dt-gozetim2-aday-denetci thead');
    $('.dt-gozetim2-aday-denetci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_gozetim2_aday_denetci.column(i).search() !== this.value) {
          dt_gozetim2_aday_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_gozetim2_aday_denetci = dt_gozetim2_aday_denetci_table.DataTable({
      ajax: dtAdayDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_gozetim2_aday_denetci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'gad2\', \'gozetim2-aday-denetci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_gozetim2_aday_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_gozetim2_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_gozetim2_aday_denetci);
    // }
  }

  if (dt_yb_basdenetci_table.length && asama === 'yb') {
    // Setup - add a text input to each footer cell
    $('.dt-yb-basdenetciler thead tr').clone(true).appendTo('.dt-yb-basdenetciler thead');
    $('.dt-yb-basdenetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_yb_basdenetci.column(i).search() !== this.value) {
          dt_yb_basdenetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_yb_basdenetci = dt_yb_basdenetci_table.DataTable({
      ajax: dtBasdenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="radio" id="dt_yb_basdenetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setBasdenetci(\'ybbd\', \'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="radio" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'single'
      }
    });
    dt_yb_basdenetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_yb_basdenetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_yb_basdenetci);
    }
  }

  if (dt_yb_denetci_table.length && asama === 'yb') {
    // Setup - add a text input to each footer cell
    $('.dt-yb-denetciler thead tr').clone(true).appendTo('.dt-yb-denetciler thead');
    $('.dt-yb-denetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_yb_denetci.column(i).search() !== this.value) {
          dt_yb_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_yb_denetci = dt_yb_denetci_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_yb_denetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ybd\', \'yb-denetciler\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_yb_denetci.columns.adjust().draw();

    // Fixed header
    if (window.Helpers.isNavbarFixed()) {
      navHeight = $('#layout-navbar').outerHeight();
      new $.fn.dataTable.FixedHeader(dt_yb_denetci).headerOffset(navHeight);
    } else {
      new $.fn.dataTable.FixedHeader(dt_yb_denetci);
    }
  }

  if (dt_yb_teknik_uzman_table.length && asama === 'yb') {
    // Setup - add a text input to each footer cell
    $('.dt-yb-teknik-uzman thead tr').clone(true).appendTo('.dt-yb-teknik-uzman thead');
    $('.dt-yb-teknik-uzman thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_yb_teknik_uzman.column(i).search() !== this.value) {
          dt_yb_teknik_uzman.column(i).search(this.value).draw();
        }
      });
    });

    var dt_yb_teknik_uzman = dt_yb_teknik_uzman_table.DataTable({
      ajax: dtTeknikUzmanRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_yb_teknik_uzman' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ybtu\', \'yb-teknik-uzman\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_yb_teknik_uzman.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_yb_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_yb_teknik_uzman);
    // }
  }

  if (dt_yb_gozlemci_table.length && asama === 'yb') {
    // Setup - add a text input to each footer cell
    $('.dt-yb-gozlemci thead tr').clone(true).appendTo('.dt-yb-gozlemci thead');
    $('.dt-yb-gozlemci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_yb_gozlemci.column(i).search() !== this.value) {
          dt_yb_gozlemci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_yb_gozlemci = dt_yb_gozlemci_table.DataTable({
      ajax: dtGozlemciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_yb_gozlemci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ybg\', \'yb-gozlemci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_yb_gozlemci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_yb_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_yb_teknik_uzman);
    // }
  }

  if (dt_yb_iku_table.length && asama === 'yb') {
    // Setup - add a text input to each footer cell
    $('.dt-yb-iku thead tr').clone(true).appendTo('.dt-yb-iku thead');
    $('.dt-yb-iku thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_yb_iku.column(i).search() !== this.value) {
          dt_yb_iku.column(i).search(this.value).draw();
        }
      });
    });

    var dt_yb_iku = dt_yb_iku_table.DataTable({
      ajax: dtIkuRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_yb_iku' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ybiku\', \'yb-iku\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_yb_iku.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_yb_iku).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_yb_iku);
    // }
  }

  if (dt_yb_aday_denetci_table.length && asama === 'yb') {
    // Setup - add a text input to each footer cell
    $('.dt-yb-aday-denetci thead tr').clone(true).appendTo('.dt-yb-aday-denetci thead');
    $('.dt-yb-aday-denetci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_yb_aday_denetci.column(i).search() !== this.value) {
          dt_yb_aday_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_yb_aday_denetci = dt_yb_aday_denetci_table.DataTable({
      ajax: dtAdayDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_yb_aday_denetci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ybad\', \'yb-aday-denetci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_yb_aday_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_yb_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_yb_aday_denetci);
    // }
  }

  if (dt_ot_basdenetci_table.length && asama === 'ozel') {
    // Setup - add a text input to each footer cell
    $('.dt-ot-basdenetciler thead tr').clone(true).appendTo('.dt-ot-basdenetciler thead');
    $('.dt-ot-basdenetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_ot_basdenetci.column(i).search() !== this.value) {
          dt_ot_basdenetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_ot_basdenetci = dt_ot_basdenetci_table.DataTable({
      ajax: dtBasdenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="radio" id="dt_ot_basdenetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setBasdenetci(\'otbd\', \'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="radio" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'single'
      }
    });
    dt_ot_basdenetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_basdenetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_basdenetci);
    // }
  }

  if (dt_ot_denetci_table.length && asama === 'ozel') {
    // Setup - add a text input to each footer cell
    $('.dt-ot-denetciler thead tr').clone(true).appendTo('.dt-ot-denetciler thead');
    $('.dt-ot-denetciler thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_ot_denetci.column(i).search() !== this.value) {
          dt_ot_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_ot_denetci = dt_ot_denetci_table.DataTable({
      ajax: dtDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_ot_denetci_table_' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'otd\', \'ot-denetciler\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_ot_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_denetci);
    // }
  }

  if (dt_ot_teknik_uzman_table.length && asama === 'ozel') {
    // Setup - add a text input to each footer cell
    $('.dt-ot-teknik-uzman thead tr').clone(true).appendTo('.dt-ot-teknik-uzman thead');
    $('.dt-ot-teknik-uzman thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_ot_teknik_uzman.column(i).search() !== this.value) {
          dt_ot_teknik_uzman.column(i).search(this.value).draw();
        }
      });
    });

    var dt_ot_teknik_uzman = dt_ot_teknik_uzman_table.DataTable({
      ajax: dtTeknikUzmanRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_ot_teknik_uzman' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'ottu\', \'ot-teknik-uzman\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_ot_teknik_uzman.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_teknik_uzman);
    // }
  }

  if (dt_ot_gozlemci_table.length && asama === 'ozel') {
    // Setup - add a text input to each footer cell
    $('.dt-ot-gozlemci thead tr').clone(true).appendTo('.dt-ot-gozlemci thead');
    $('.dt-ot-gozlemci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_ot_gozlemci.column(i).search() !== this.value) {
          dt_ot_gozlemci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_ot_gozlemci = dt_ot_gozlemci_table.DataTable({
      ajax: dtGozlemciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' }, { data: 'sistemler' },
        { data: 'nace' },
        { data: 'kategori' },
        { data: 'kategorioic' },
        { data: 'kategoribg' },
        { data: 'teknikalan' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_ot_gozlemci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'otg\', \'ot-gozlemci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 2,
          render: function(data, type, full, meta) {
            var $name = full['denetci'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '20%',
          targets: 3,
          render: function(data, type, full, meta) {
            var $name = full['sistemler'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          // kuruluş adı/adesi/kapsamı
          width: '30%',
          targets: 4,
          render: function(data, type, full, meta) {
            var $name = full['nace'];
            // Creates full output for row
            var $row_output =
              '<div class="d-flex justify-content-start align-items-center">' +
              '<div class="d-flex flex-column">' +
              '<span class="emp_name text-truncate text-heading fw-medium text-wrap">' +
              $name +
              '</span>' +
              '</div>' +
              '</div>';
            return $row_output;
          }
        },
        {
          width: '10%',
          targets: 5
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_ot_gozlemci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_teknik_uzman).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_teknik_uzman);
    // }
  }

  if (dt_ot_iku_table.length && asama === 'ozel') {
    // Setup - add a text input to each footer cell
    $('.dt-ot-iku thead tr').clone(true).appendTo('.dt-ot-iku thead');
    $('.dt-ot-iku thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_ot_iku.column(i).search() !== this.value) {
          dt_ot_iku.column(i).search(this.value).draw();
        }
      });
    });

    var dt_ot_iku = dt_ot_iku_table.DataTable({
      ajax: dtIkuRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_ot_iku' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'otiku\', \'ot-iku\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_ot_iku.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_iku).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_iku);
    // }
  }

  if (dt_ot_aday_denetci_table.length && asama === 'ozel') {
    // Setup - add a text input to each footer cell
    $('.dt-ot-aday-denetci thead tr').clone(true).appendTo('.dt-ot-aday-denetci thead');
    $('.dt-ot-aday-denetci thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (dt_ot_aday_denetci.column(i).search() !== this.value) {
          dt_ot_aday_denetci.column(i).search(this.value).draw();
        }
      });
    });

    var dt_ot_aday_denetci = dt_ot_aday_denetci_table.DataTable({
      ajax: dtAdayDenetciRoutePath,
      columns: [
        { data: 'id' },
        { data: 'id' },
        { data: 'denetci' },
        { data: 'sistemler' }
      ],
      columnDefs: [
        {
          // For Checkboxes
          targets: 0,
          searchable: false,
          orderable: false,
          width: '10px',
          render: function(data, type, full, meta) {
            var chkvalue = full['denetci'];
            return '<input type="checkbox" id="dt_ot_aday_denetci' + full['id'] + '" value="' + chkvalue + '" onclick="setDenetci(\'otad\', \'ot-aday-denetci\')" class="dt-checkboxes form-check-input">';
          },
          checkboxes: {
            selectRow: true,
            selectAllRender: '<input type="checkbox" class="form-check-input">'
          }
        }

      ],
      orderCellsTop: true,
      order: [[1, 'asc']],
      dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    dt_ot_aday_denetci.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_aday_denetci);
    // }
  }

  if (tblbelgelifirmalarals05.length) {
    // Setup - add a text input to each footer cell
    $('#tblbelgelifirmalarals05 thead tr').clone(true).appendTo('#tblbelgelifirmalarals05 thead');
    $('#tblbelgelifirmalarals05 thead tr:eq(1) th').each(function(i) {
      var title = $(this).text();
      $(this).html('<input type="text" class="form-control" placeholder="Search ' + title + '" />');

      $('input', this).on('keyup change', function() {
        if (belgelifirmalarals05.column(i).search() !== this.value) {
          belgelifirmalarals05.column(i).search(this.value).draw();
        }
      });
    });

    var belgelifirmalarals05 = tblbelgelifirmalarals05.DataTable({
      // ajax: tblbelgelifirmalarals05RoutePath,
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-secondary dropdown-toggle me-3 waves-effect waves-light',
          text: '<i class="mdi mdi-export-variant me-1"></i> <span class="d-none d-sm-inline-block">Dışarı Aktar</span>',
          buttons: [
            {
              extend: 'excelHtml5',
              autoFilter: true,
              text: '<i class="mdi mdi-file-excel-outline me-1"></i>Excel',
              className: 'dropdown-item',
              exportOptions: {
                // columns: [1, 2, 3, 4, 5, 6, 7],
              }
            },
            {
              extend: 'pdf',
              text: '<i class="mdi mdi-file-pdf-box me-1"></i>Pdf',
              className: 'dropdown-item',
            }
          ]
        }
      ],
      orderCellsTop: true,
      order: [[12, 'desc']],
      dom:
        '<"row mx-2"' +
        '<"col-md-2"<"me-3"l>>' +
        '<"col-md-10"<"dt-action-buttons text-xl-end text-lg-start text-md-end text-start d-flex align-items-center justify-content-end flex-md-row flex-column mb-3 mb-md-0 gap-3"fB>>' +
        '>t' +
        '<"row mx-2"' +
        '<"col-sm-12 col-md-6"i>' +
        '<"col-sm-12 col-md-6"p>' +
        '>',
      language: {
        "info": "_TOTAL_ kayıttan _START_ - _END_ arasındaki kayıtlar gösteriliyor",
        "infoEmpty": "Kayıt yok",
        "infoFiltered": "(_MAX_ kayıt içerisinden bulunan)",
        "infoThousands": ".",
        "lengthMenu": "Sayfada _MENU_ kayıt göster",
        "loadingRecords": "Yükleniyor...",
        "processing": "İşleniyor...",
        "search": "",
        "zeroRecords": "Eşleşen kayıt bulunamadı",
        "paginate": {
          "first": "İlk",
          "last": "Son",
          "next": "Sonraki",
          "previous": "Önceki"
        },
        "aria": {
          "sortAscending": ": artan sütun sıralamasını aktifleştir",
          "sortDescending": ": azalan sütun sıralamasını aktifleştir"
        },
        "select": {
          "rows": {
            "_": "%d kayıt seçildi",
            "1": "1 kayıt seçildi"
          },
          "cells": {
            "1": "1 hücre seçildi",
            "_": "%d hücre seçildi"
          },
          "columns": {
            "1": "1 sütun seçildi",
            "_": "%d sütun seçildi"
          }
        },
        "autoFill": {
          "cancel": "İptal",
          "fillHorizontal": "Hücreleri yatay olarak doldur",
          "fillVertical": "Hücreleri dikey olarak doldur",
          "fill": "Bütün hücreleri <i>%d<\/i> ile doldur",
          "info": "Detayı"
        },
        "buttons": {
          "collection": "Koleksiyon <span class=\"ui-button-icon-primary ui-icon ui-icon-triangle-1-s\"><\/span>",
          "colvis": "Sütun görünürlüğü",
          "colvisRestore": "Görünürlüğü eski haline getir",
          "copySuccess": {
            "1": "1 satır panoya kopyalandı",
            "_": "%ds satır panoya kopyalandı"
          },
          "copyTitle": "Panoya kopyala",
          "csv": "CSV",
          "excel": "Excel",
          "pageLength": {
            "-1": "Bütün satırları göster",
            "_": "%d satır göster",
            "1": "1 Satır Göster"
          },
          "pdf": "PDF",
          "print": "Yazdır",
          "copy": "Kopyala",
          "copyKeys": "Tablodaki veriyi kopyalamak için CTRL veya u2318 + C tuşlarına basınız. İptal etmek için bu mesaja tıklayın veya escape tuşuna basın.",
          "createState": "Şuanki Görünümü Kaydet",
          "removeAllStates": "Tüm Görünümleri Sil",
          "removeState": "Aktif Görünümü Sil",
          "renameState": "Aktif Görünümün Adını Değiştir",
          "savedStates": "Kaydedilmiş Görünümler",
          "stateRestore": "Görünüm -&gt; %d",
          "updateState": "Aktif Görünümün Güncelle"
        },
        "searchBuilder": {
          "add": "Koşul Ekle",
          "button": {
            "0": "Arama Oluşturucu",
            "_": "Arama Oluşturucu (%d)"
          },
          "condition": "Koşul",
          "conditions": {
            "date": {
              "after": "Sonra",
              "before": "Önce",
              "between": "Arasında",
              "empty": "Boş",
              "equals": "Eşittir",
              "not": "Değildir",
              "notBetween": "Dışında",
              "notEmpty": "Dolu"
            },
            "number": {
              "between": "Arasında",
              "empty": "Boş",
              "equals": "Eşittir",
              "gt": "Büyüktür",
              "gte": "Büyük eşittir",
              "lt": "Küçüktür",
              "lte": "Küçük eşittir",
              "not": "Değildir",
              "notBetween": "Dışında",
              "notEmpty": "Dolu"
            },
            "string": {
              "contains": "İçerir",
              "empty": "Boş",
              "endsWith": "İle biter",
              "equals": "Eşittir",
              "not": "Değildir",
              "notEmpty": "Dolu",
              "startsWith": "İle başlar",
              "notContains": "İçermeyen",
              "notStartsWith": "Başlamayan",
              "notEndsWith": "Bitmeyen"
            },
            "array": {
              "contains": "İçerir",
              "empty": "Boş",
              "equals": "Eşittir",
              "not": "Değildir",
              "notEmpty": "Dolu",
              "without": "Hariç"
            }
          },
          "data": "Veri",
          "deleteTitle": "Filtreleme kuralını silin",
          "leftTitle": "Kriteri dışarı çıkart",
          "logicAnd": "ve",
          "logicOr": "veya",
          "rightTitle": "Kriteri içeri al",
          "title": {
            "0": "Arama Oluşturucu",
            "_": "Arama Oluşturucu (%d)"
          },
          "value": "Değer",
          "clearAll": "Filtreleri Temizle"
        },
        "searchPanes": {
          "clearMessage": "Hepsini Temizle",
          "collapse": {
            "0": "Arama Bölmesi",
            "_": "Arama Bölmesi (%d)"
          },
          "count": "{total}",
          "countFiltered": "{shown}\/{total}",
          "emptyPanes": "Arama Bölmesi yok",
          "loadMessage": "Arama Bölmeleri yükleniyor ...",
          "title": "Etkin filtreler - %d",
          "showMessage": "Tümünü Göster",
          "collapseMessage": "Tümünü Gizle"
        },
        "thousands": ".",
        "datetime": {
          "amPm": [
            "öö",
            "ös"
          ],
          "hours": "Saat",
          "minutes": "Dakika",
          "next": "Sonraki",
          "previous": "Önceki",
          "seconds": "Saniye",
          "unknown": "Bilinmeyen",
          "weekdays": {
            "6": "Paz",
            "5": "Cmt",
            "4": "Cum",
            "3": "Per",
            "2": "Çar",
            "1": "Sal",
            "0": "Pzt"
          },
          "months": {
            "9": "Ekim",
            "8": "Eylül",
            "7": "Ağustos",
            "6": "Temmuz",
            "5": "Haziran",
            "4": "Mayıs",
            "3": "Nisan",
            "2": "Mart",
            "11": "Aralık",
            "10": "Kasım",
            "1": "Şubat",
            "0": "Ocak"
          }
        },
        "decimal": ",",
        "editor": {
          "close": "Kapat",
          "create": {
            "button": "Yeni",
            "submit": "Kaydet",
            "title": "Yeni kayıt oluştur"
          },
          "edit": {
            "button": "Düzenle",
            "submit": "Güncelle",
            "title": "Kaydı düzenle"
          },
          "error": {
            "system": "Bir sistem hatası oluştu (Ayrıntılı bilgi)"
          },
          "multi": {
            "info": "Seçili kayıtlar bu alanda farklı değerler içeriyor. Seçili kayıtların hepsinde bu alana aynı değeri atamak için buraya tıklayın; aksi halde her kayıt bu alanda kendi değerini koruyacak.",
            "noMulti": "Bu alan bir grup olarak değil ancak tekil olarak düzenlenebilir.",
            "restore": "Değişiklikleri geri al",
            "title": "Çoklu değer"
          },
          "remove": {
            "button": "Sil",
            "confirm": {
              "_": "%d adet kaydı silmek istediğinize emin misiniz?",
              "1": "Bu kaydı silmek istediğinizden emin misiniz?"
            },
            "submit": "Sil",
            "title": "Kayıtları sil"
          }
        },
        "stateRestore": {
          "creationModal": {
            "button": "Kaydet",
            "columns": {
              "search": "Kolon Araması",
              "visible": "Kolon Görünümü"
            },
            "name": "Görünüm İsmi",
            "order": "Sıralama",
            "paging": "Sayfalama",
            "scroller": "Kaydırma (Scrool)",
            "search": "",
            "searchBuilder": "Arama Oluşturucu",
            "select": "Seçimler",
            "title": "Yeni Görünüm Oluştur",
            "toggleLabel": "Kaydedilecek Olanlar"
          },
          "duplicateError": "Bu Görünüm Daha Önce Tanımlanmış",
          "emptyError": "Görünüm Boş Olamaz",
          "emptyStates": "Herhangi Bir Görünüm Yok",
          "removeJoiner": "ve",
          "removeSubmit": "Sil",
          "removeTitle": "Görünüm Sil",
          "renameButton": "Değiştir",
          "renameLabel": "Görünüme Yeni İsim Ver -&gt; %s:",
          "renameTitle": "Görünüm İsmini Değiştir",
          "removeConfirm": "Görünümü silmek istediğinize emin misiniz?",
          "removeError": "Görünüm silinemedi"
        },
        "emptyTable": "Tabloda veri bulunmuyor",
        "searchPlaceholder": "Arayın...",
        "infoPostFix": " "
      },
      paging: false,
      scrollX: true,
      scrollY: '400px',
      select: {
        // Select style
        style: 'multi'
      }
    });
    belgelifirmalarals05.columns.adjust().draw();

    // Fixed header
    // if (window.Helpers.isNavbarFixed()) {
    //   navHeight = $('#layout-navbar').outerHeight();
    //   new $.fn.dataTable.FixedHeader(dt_ot_aday_denetci).headerOffset(navHeight);
    // } else {
    //   new $.fn.dataTable.FixedHeader(dt_ot_aday_denetci);
    // }
  }

  // Filter form control to default size
  // ? setTimeout used for multilingual table initialization
  setTimeout(() => {
    $('.dataTables_filter .form-control').removeClass('form-control-sm');
    $('.dataTables_length .form-select').removeClass('form-select-sm');
  }, 300);
  denetimTakvimiGoster();
});

function setEaNaceKategori(val) {
  var ea = [],
    nace = [],
    kk9 = [],
    kk14 = [],
    kk45 = [],
    ea1 = [],
    nace1 = [],
    kk91 = [],
    kk141 = [],
    kk451 = [];

  $('#dt-ea-nace-kodlari-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var kk9tmp = row.find('td:eq(2)').text().trim();
      var kk14tmp = row.find('td:eq(3)').text().trim();
      var kk45tmp = row.find('td:eq(4)').text().trim();
      var eatmp = row.find('td:eq(5)').text().trim();
      var nacetmp = row.find('td:eq(6)').text().trim();

      if (kk9.length < 0) {
        kk9.push(kk9tmp);
      } else {
        if (kk9.indexOf(kk9tmp) === -1) {
          kk9.push(kk9tmp);
        }
      }
      kk9.sort();

      if (kk14.length < 0) {
        kk14.push(kk14tmp);
      } else {
        if (kk14.indexOf(kk14tmp) === -1) {
          kk14.push(kk14tmp);
        }
      }
      kk14.sort();

      if (kk45.length < 0) {
        kk45.push(kk45tmp);
      } else {
        if (kk45.indexOf(kk45tmp) === -1) {
          kk45.push(kk45tmp);
        }
      }
      kk45.sort();

      if (ea.length < 0) {
        ea.push(eatmp);
      } else {
        if (ea.indexOf(eatmp) === -1) {
          ea.push(eatmp);
        }
      }
      ea.sort();

      if (nace.length < 0) {
        nace.push(nacetmp);
      } else {
        if (nace.indexOf(nacetmp) === -1) {
          nace.push(nacetmp);
        }
      }
      nace.sort();
    }

  });

  $('#lbl_ea').text('[Q:' + kk9 + ', E:' + kk14 + ', O:' + kk45 + '] ' + ea);
  $('#diveanace').html('[Q:' + kk9 + ', E:' + kk14 + ', O:' + kk45 + '] ' + ea + '|' + nace);

  $('#gizliea').val(ea);
  $('#gizlinace').val(nace);
  $('#riskgrubu9').val(kk9);
  $('#riskgrubu14').val(kk14);
  $('#riskgrubu45').val(kk45);

  var kats22 = [],
    bb22 = parseFloat('0'),
    cc22 = parseFloat('0');

  $('#dt-22000-kategori-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var katstmp = row.find('td:eq(2)').text().trim();
      var bbtmp = parseFloat(row.find('td:eq(5)').text().trim().replace(',', '.'));
      var cctmp = parseFloat(row.find('td:eq(6)').text().trim().replace(',', '.'));

      if (kats22.length < 0) {
        kats22.push(katstmp);
      } else {
        if (kats22.indexOf(katstmp) === -1) {
          kats22.push(katstmp);
        }
      }
      kats22.sort();

      if (bb22 === 0) {
        bb22 = bbtmp;
        cc22 = cctmp;
      } else {
        if (bb22 < bbtmp) {
          bb22 = bbtmp;
          cc22 = cctmp;
        }
      }
      // bb22.sort();
      //
      // if (cc22.length < 0) {
      //   cc22.push(cctmp);
      // } else {
      //   if (cc22.indexOf(cctmp) === -1) {
      //     cc22.push(cctmp);
      //   }
      // }
      // cc22.sort();
    }

  });

  $('#div22cat').html(kats22 + ' ::: bb::' + bb22 + ' ::: cc::' + cc22);
  $('#gizlikat').val(kats22);
  $('#gizlikatbb').val(bb22);
  $('#gizlikatcc').val(cc22);

  var katsoic = [],
    bboic = parseFloat('0'),
    ccoic = parseFloat('0');

  $('#dt-smiic-kategori-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var katstmp = row.find('td:eq(2)').text().trim();
      var bbtmp = parseFloat(row.find('td:eq(6)').text().trim().replace(',', '.'));
      var cctmp = parseFloat(row.find('td:eq(7)').text().trim().replace(',', '.'));

      if (katsoic.length < 0) {
        katsoic.push(katstmp);
      } else {
        if (katsoic.indexOf(katstmp) === -1) {
          katsoic.push(katstmp);
        }
      }
      katsoic.sort();

      if (bboic === 0) {
        bboic = bbtmp;
        ccoic = cctmp;
      } else {
        if (bboic < bbtmp) {
          bboic = bbtmp;
          ccoic = cctmp;
        }
      }

      // if (bboic.length < 0) {
      //   bboic.push(bbtmp);
      // } else {
      //   if (bboic.indexOf(bbtmp) === -1) {
      //     bboic.push(bbtmp);
      //   }
      // }
      // bboic.sort();
      //
      // if (ccoic.length < 0) {
      //   ccoic.push(cctmp);
      // } else {
      //   if (ccoic.indexOf(cctmp) === -1) {
      //     ccoic.push(cctmp);
      //   }
      // }
      // ccoic.sort();
    }

  });

  $('#divoiccat').html(katsoic + ' ::: bb::' + bboic + ' ::: cc::' + ccoic);
  $('#gizlioickat').val(katsoic);
  $('#gizlikatbboic').val(bboic);
  $('#gizlikatccoic').val(ccoic);

  var ta27001 = [], tag27001 = [];
  $('#dt-27001-kategori-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var katstmp = row.find('td:eq(5)').text().trim();
      var katsgtmp = row.find('td:eq(6)').text().trim();

      if (ta27001.length < 0) {
        ta27001.push(katstmp);
      } else {
        if (ta27001.indexOf(katstmp) === -1) {
          ta27001.push(katstmp);
        }
      }
      ta27001.sort();

      if (tag27001.length < 0) {
        tag27001.push(katsgtmp);
      } else {
        if (tag27001.indexOf(katsgtmp) === -1) {
          tag27001.push(katsgtmp);
        }
      }
      tag27001.sort();
    }

  });

  $('#div27001cat').html(ta27001 + ' ::: tag27001::' + tag27001);
  $('#gizlibgys').val(ta27001);

  var ta50001 = [], tag50001 = [];

  $('#dt-50001-kategori-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var katstmp = row.find('td:eq(2)').text().trim();
      var katsgtmp = row.find('td:eq(4)').text().trim();

      if (ta50001.length < 0) {
        ta50001.push(katstmp);
      } else {
        if (ta50001.indexOf(katstmp) === -1) {
          ta50001.push(katstmp);
        }
      }
      ta50001.sort();

      if (tag50001.length < 0) {
        tag50001.push(katsgtmp);
      } else {
        if (tag50001.indexOf(katsgtmp) === -1) {
          tag50001.push(katsgtmp);
        }
      }
      tag50001.sort();
    }

  });

  $('#div50001cat').html(ta50001 + ' ::: tag50001::' + tag50001);
  $('#gizlienysta').val(ta50001);

  setLblEaNaceKats(nace, kats22, katsoic, ta50001, ta27001);
  // getDenetimOnerilenBasdenetci();
}

function setLblEaNaceKats(valuenace, valuekat, valueoickat, valueenysta, valuebgys) {
  var lbleanacekat = $('#lbl_eanacekat');
  // console.log(valuenace.length + "|" + valuekat.length + "ß" + valueoickat.length + "Æ" + valueenysta.length + "€" + valuebgys.length);
  if (valuenace.length > 0 && valuekat.length === 0 && valueoickat.length === 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuenace.toString());
  } else if (valuenace.length === 0 && valuekat.length > 0 && valueoickat.length === 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuekat.toString());
  } else if (valuenace.length === 0 && valuekat.length === 0 && valueoickat.length > 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valueoickat.toString());
  } else if (valuenace.length === 0 && valuekat.length === 0 && valueoickat.length === 0 && valueenysta.length > 0 && valuebgys.length === 0) {
    lbleanacekat.val(valueenysta.toString());
  } else if (valuenace.length === 0 && valuekat.length === 0 && valueoickat.length === 0 && valueenysta.length === 0 && valuebgys.length > 0) {
    lbleanacekat.val(valuebgys.toString());
  } else if (valuenace.length > 0 && valuekat.length > 0 && valueoickat.length === 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuenace.toString() + '|' + valuekat.toString());
  } else if (valuenace.length > 0 && valuekat.length === 0 && valueoickat.length > 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuenace.toString() + 'ß' + valueoickat.toString());
  } else if (valuenace.length > 0 && valuekat.length === 0 && valueoickat.length === 0 && valueenysta.length > 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuenace.toString() + 'Æ' + valueenysta.toString());
  } else if (valuenace.length === 0 && valuekat.length > 0 && valueoickat.length > 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuekat.toString() + 'ß' + valueoickat.toString());
  } else if (valuenace.length === 0 && valuekat.length > 0 && valueoickat.length === 0 && valueenysta.length > 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuekat.toString() + 'Æ' + valueenysta.toString());
  } else if (valuenace.length === 0 && valuekat.length === 0 && valueoickat.length === 0 && valueenysta.length > 0 && valuebgys.length > 0) {
    lbleanacekat.val(valueenysta.toString() + '€' + valuebgys.toString());
  } else if (valuenace.length > 0 && valuekat.length > 0 && valueoickat.length > 0 && valueenysta.length === 0 && valuebgys.length === 0) {
    lbleanacekat.val(valuenace.toString() + '|' + valuekat.toString() + 'ß' + valueoickat.toString());
  } else if (valuenace.length > 0 && valuekat.length > 0 && valueoickat.length > 0 && valueenysta.length === 0 && valuebgys.length > 0) {
    lbleanacekat.val(valuenace.toString() + '|' + valuekat.toString() + 'ß' + valueoickat.toString() + '€' + valuebgys.toString());
  } else if (valuenace.length > 0 && valuekat.length > 0 && valueoickat.length > 0 && valueenysta.length > 0 && valuebgys.length > 0) {
    lbleanacekat.val(valuenace.toString() + '|' + valuekat.toString() + 'ß' + valueoickat.toString() + 'Æ' + valueenysta.toString() + '€' + valuebgys.toString());
  } else {
    lbleanacekat.val('NA');
  }
}

function getDenetimOnerilenBasdenetci() {
  var nace = $('#gizlinace').val().replace('|', '');
  var kat22 = $('#gizlikat').val().replace('@', '');
  var katoic = $('#gizlioickat').val().replace('ß', '');
  var tabgys = $('#gizlibgys').val().replace('€', '');
  var taenys = $('#gizlienysta').val().replace('Æ', '');

  var postData = 'nace=' + nace + '&kat22=' + kat22 + '&katoic=' + katoic + '&tabgys=' + tabgys + '&taenys=' + taenys;
  var formURL = getDenetimOnerilenBasdenetciPath; //$("#getDenetimOnerilenBasdenetciRoute").val();

  // console.log("formKaydet::route:: ");
  // console.log("getDenetimOnerilenBasdenetci::postData:: " + formURL + "?" + postData);
  $.ajax({
    url: formURL,
    type: 'GET',
    data: postData,
    success: function(html) {
      var dt_denetim_onerilen_basdenetci_table = $('.dt-denetim-onerilen-basdenetci');
      if (dt_denetim_onerilen_basdenetci_table.length) {
        // Setup - add a text input to each footer cell
        $('.dt-denetim-onerilen-basdenetci thead tr').clone(true).appendTo('.dt-denetim-onerilen-basdenetci thead');
        $('.dt-denetim-onerilen-basdenetci thead tr:eq(1) th').each(function(i) {
          var title = $(this).text();
          $(this).html('<input type="text" class="form-control" placeholder="' + title + '" />');

          $('input', this).on('keyup change', function() {
            if (dt_denetim_onerilen_basdenetci.column(i).search() !== this.value) {
              dt_denetim_onerilen_basdenetci.column(i).search(this.value).draw();
            }
          });
        });

        var dt_denetim_onerilen_basdenetci = dt_denetim_onerilen_basdenetci_table.DataTable({
          data: html,
          columns: [
            { data: 'id' },
            { data: 'id' },
            { data: 'denetci' },
            { data: 'ea' },
            { data: 'nace' },
            { data: 'kategori' },
            { data: 'kategorioic' },
            { data: 'kategoribg' },
            { data: 'teknikalan' }
          ],
          columnDefs: [
            {
              // For Checkboxes
              targets: 0,
              searchable: false,
              orderable: false,
              width: '10px',
              render: function(data, type, full, meta) {
                var chkvalue = full['denetci'];
                return '<input type="radio" id="dt_denetim_onerilen_basdenetci_table' + full['id'] + '" value="' + chkvalue + '" onclick="setOnerilenBasdenetci(\'' + chkvalue + '\')" class="dt-checkboxes form-check-input">';
              },
              checkboxes: {
                selectRow: true,
                selectAllRender: '<input type="radio" class="form-check-input">'
              }
            },
            {
              targets: 2,
              width: '100px'
            },
            {
              targets: 3,
              width: '150px'
            },
            {
              targets: 4,
              width: '150px'
            }

          ],
          orderCellsTop: true,
          order: [[1, 'asc']],
          dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
          paging: false,
          scrollX: true,
          scrollY: '400px',
          retrieve: true,
          select: {
            // Select style
            style: 'single'
          },
          autoWidth: false
        });
        dt_denetim_onerilen_basdenetci.columns.adjust().draw();

      }
      getOnerilenKararUyeleri();
      hesapla();
      // $("#divDenetimOnerilenBasdenetci").html(html);
    },
    error: function(jqXHR, textStatus, errorThrown) {
      $('#formkaydetsonucerror').html('[getDenetimOnerilenBasdenetci]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
      // window.console.log("formKaydet: " + formURL + "?" + postData);
      $('#myModalError').modal('show');
    }
  });
}

function setOnerilenBasdenetci(val) {
  $('#divbddenetime').val(val);
}

function getOnerilenKararUyeleri() {
  var postData = 'ea=' + $('#gizliea').val() + '&kat22=' + $('#gizlikat').val() + '&katoic=' + $('#gizlioickat').val() + '&tabgys=' + $('#gizlibgys').val() + '&taenys=' + $('#gizlienysta').val();

  var formURL = getOnerilenKararUyeleriPath; //$("#getDenetimOnerilenBasdenetciRoute").val();

  // console.log("formKaydet::route:: ");
  // console.log("getDenetimOnerilenBasdenetci::postData:: " + formURL + "?" + postData);
  $.ajax({
    url: formURL,
    type: 'GET',
    data: postData,
    success: function(html) {
      var dt_denetim_onerilen_karar_uye_table = $('.dt-denetim-onerilen-karar-uye');
      if (dt_denetim_onerilen_karar_uye_table.length) {
        // Setup - add a text input to each footer cell
        $('.dt-denetim-onerilen-karar-uye thead tr').clone(true).appendTo('.dt-denetim-onerilen-karar-uye thead');
        $('.dt-denetim-onerilen-karar-uye thead tr:eq(1) th').each(function(i) {
          var title = $(this).text();
          $(this).html('<input type="text" class="form-control" placeholder="' + title + '" />');

          $('input', this).on('keyup change', function() {
            if (dt_denetim_onerilen_karar_uye.column(i).search() !== this.value) {
              dt_denetim_onerilen_karar_uye.column(i).search(this.value).draw();
            }
          });
        });

        var dt_denetim_onerilen_karar_uye = dt_denetim_onerilen_karar_uye_table.DataTable({
          data: html,
          columns: [
            { data: 'id' },
            { data: 'id' },
            { data: 'denetci' },
            { data: 'ea' },
            { data: 'kategori' },
            { data: 'kategorioic' },
            { data: 'kategoribg' },
            { data: 'teknikalan' }
          ],
          columnDefs: [
            {
              // For Checkboxes
              targets: 0,
              searchable: false,
              orderable: false,
              width: '10px',
              render: function(data, type, full, meta) {
                var chkvalue = full['denetci'];
                return '<input type="checkbox" id="dt_denetim_onerilen_karar_uye_table' + full['id'] + '" value="' + chkvalue + '" onclick="setOnerilenKararUyeleri()" class="dt-checkboxes form-check-input">';
              },
              checkboxes: {
                selectRow: true,
                selectAllRender: '<input type="checkbox" class="form-check-input">'
              }
            }

          ],
          orderCellsTop: true,
          order: [[1, 'asc']],
          dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>><"table-responsive"t><"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
          paging: false,
          scrollX: true,
          scrollY: '400px',
          retrieve: true,
          select: {
            // Select style
            style: 'multi'
          },
          autoWidth: false
        });
        dt_denetim_onerilen_karar_uye.columns.adjust().draw();

      }
      // $("#divDenetimOnerilenBasdenetci").html(html);
    },
    error: function(jqXHR, textStatus, errorThrown) {
      $('#formkaydetsonucerror').html('[getOnerilenKararUyeleri]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
      // window.console.log("formKaydet: " + formURL + "?" + postData);
      $('#myModalError').modal('show');
    }
  });
}

function setOnerilenKararUyeleri() {
  var uyeler = [];

  $('#dt-denetim-onerilen-karar-uye-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var uyetmp = row.find('td:eq(2)').text().trim();

      if (uyeler.length < 0) {
        uyeler.push(uyetmp);
      } else {
        if (uyeler.indexOf(uyetmp) === -1) {
          uyeler.push(uyetmp);
        }
      }
      uyeler.sort();
    }

  });

  $('#divbdkararu').val(uyeler);
}

function setBasdenetci(asm, val) {
  $('#div' + asm).val(val);

  var dataString = 'denetci=' + val + '&planno=' + $('#planno').val() + '&sistemler=' + $('#belgelendirileceksistemler').val();
  var formURL = $('#denetciSistemleriRoute').val();

  $.ajax({
    type: 'GET',
    url: formURL,
    data: dataString,
    cache: false,
    success: function(html) {
      densisyet[0] = html;
      // console.log("setBasdenetcisay1: " + densisyet);
      $('#denetcisay').val('1');
    }
  });

}

function setDenetci(asm, divid) {
  var uyeler = [];
  var denetcisay = 1;
  var i;
  var g = 1;

  $('#dt-' + divid + '-body').find('tr').each(function() {
    var row = $(this);
    if (row.find('input[type="checkbox"]').is(':checked') &&
      row.find('td').val().length <= 0) {
      var uyetmp = row.find('td:eq(2)').text().trim();

      for (var h = 1; h < densisyet.length; h++) {
        densisyet.splice(h, densisyet.length);
      }

      var dataString = 'denetci=' + uyetmp + '&planno=' + $('#planno').val() + '&sistemler=' + $('#belgelendirileceksistemler').val();
      var formURL = $('#denetciSistemleriRoute').val();

      $.ajax({
        type: 'GET',
        url: formURL,
        data: dataString,
        cache: false,
        success: function(html) {
          densisyet[g] = html;
          g++;
          // console.log("setDenetcisay1: " + densisyet);
          // console.log("g: " + g);
        }
      });

      if (uyeler.length < 0) {
        uyeler.push(uyetmp);
        denetcisay += 1;
      } else {
        if (uyeler.indexOf(uyetmp) === -1) {
          uyeler.push(uyetmp);
          denetcisay += 1;
        }
      }
      uyeler.sort();
    }

  });

  $('#denetcisay').val(denetcisay.toString());
  $('#div' + asm).val(uyeler);
}

function roundNearest5(x) {
  // return x;
  return (Math.round(parseFloat(x) * 2) / 2).toFixed(1);
}

/* ISO 9001 functions */
function iso9001SureHesapla() {
  var iso900115varyok = $('#iso900115varyok').val();
  if (iso900115varyok === '1') {
    var rg = $('#riskgrubu9').val();
    var calsay = $('#toplamcalisansayisi').val();

    var postData = 'rg=' + rg + '&calsay=' + calsay;
    var formURL = $('#iso9001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso9001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso900115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip9001').attr('title', result['tooltip']);
        $('#spantip9001').text(result['tooltip']);
        $('#iso9001hamsure').val(result['sonuc']);
        $('#iso9001kalansure').val(result['sonuc']);
        $('#iso9001a1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso9001a2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso9001gsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#iso9001ybsure').val(parseFloat(result['ybsure']).toFixed(1));

        indartHesapla9001();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso9001SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartHesapla9001() {
  var form9001 = document.getElementById('write9001IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso9001hamsure').val());
  var artimax = 30;
  var eksimax = -30;
  var totoran9001 = $('#totoran9001');

  for (var i = 0; i < form9001.length; i++) {
    if (form9001.elements[i].type === 'checkbox' && form9001.elements[i].name.substring(0, 14) === 'chb_indart9001') {
      if (form9001.elements[i].checked === true) {
        oran += parseFloat(form9001.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("9001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-danger');
    totoran9001.addClass('bg-success');
    $('#indart9001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-success');
    totoran9001.removeClass('bg-danger');
    $('#indart9001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-danger');
    totoran9001.removeClass('bg-success');
    totoran9001.addClass('bg-success');
    $('#indart9001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-success');
    totoran9001.removeClass('bg-danger');
    totoran9001.addClass('bg-danger');
    $('#indart9001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran9001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);

  kalansure = ana + miktar;
  if (miktar === 0) {
    // console.log("9001 ind oran:::" + oran + ":::miktar:::" + miktar);
    $('#iso9001indart').val(miktar.toFixed(1));
    $('#iso9001azartsure').val(ana.toFixed(1));
    $('#iso9001kalansure').val(ana.toFixed(1));
  } else {
    $('#iso9001indart').val(miktar.toFixed(1));
    $('#iso9001azartsure').val(kalansure.toFixed(1));
    $('#iso9001kalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso9001a1sure').val(a1sure);
    $('#iso9001a2sure').val(a2sure);
    $('#iso9001gsure').val(gsure);
    $('#iso9001ybsure').val(ybsure);
  }

  indartToplamHesapla();
}

function iso9001SahaSureHesapla(subeno) {
  var iso900115varyok = $('#iso900115varyok').val();
  if (iso900115varyok === '1') {
    var rg = $('#riskgrubu9').val();

    var calsay = $('#sube'+subeno+'calsay').val();

    var postData = 'rg=' + rg + '&calsay=' + calsay;
    var formURL = $('#iso9001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso9001SahaSureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso900115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip9001'+subeno).attr('title', result['tooltip']);
        $('#spantip9001'+subeno).text(result['tooltip']);
        $('#iso9001hamsure'+subeno).val(result['sonuc']);
        $('#iso9001kalansure'+subeno).val(result['sonuc']);
        $('#iso9001a1sure'+subeno).val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso9001a2sure'+subeno).val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso9001gsure'+subeno).val(parseFloat(result['gsure']).toFixed(1));
        $('#iso9001ybsure'+subeno).val(parseFloat(result['ybsure']).toFixed(1));

        indartSahaHesapla9001();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso9001SahaSureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartSahaHesapla9001(subeno) {
  var form9001 = document.getElementById('write9001IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso9001hamsure' + subeno).val());
  var artimax = 30;
  var eksimax = -30;
  var totoran9001 = $('#totoran9001');

  for (var i = 0; i < form9001.length; i++) {
    if (form9001.elements[i].type === 'checkbox' && form9001.elements[i].name.substring(0, 14) === 'chb_indart9001') {
      if (form9001.elements[i].checked === true) {
        oran += parseFloat(form9001.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("9001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-danger');
    totoran9001.addClass('bg-success');
    $('#indart9001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-success');
    totoran9001.removeClass('bg-danger');
    $('#indart9001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-danger');
    totoran9001.removeClass('bg-success');
    totoran9001.addClass('bg-success');
    $('#indart9001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran9001.removeClass('bg-primary');
    totoran9001.removeClass('bg-success');
    totoran9001.removeClass('bg-danger');
    totoran9001.addClass('bg-danger');
    $('#indart9001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran9001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);

  kalansure = ana + miktar;
  if (miktar === 0) {
    // console.log("9001 ind oran:::" + oran + ":::miktar:::" + miktar);
    $('#iso9001indart' + subeno).val(miktar.toFixed(1));
    $('#iso9001azartsure' + subeno).val(ana.toFixed(1));
    $('#iso9001kalansure' + subeno).val(ana.toFixed(1));
  } else {
    $('#iso9001indart' + subeno).val(miktar.toFixed(1));
    $('#iso9001azartsure' + subeno).val(kalansure.toFixed(1));
    $('#iso9001kalansure' + subeno).val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso9001a1sure' + subeno).val(a1sure);
    $('#iso9001a2sure' + subeno).val(a2sure);
    $('#iso9001gsure' + subeno).val(gsure);
    $('#iso9001ybsure' + subeno).val(ybsure);
  }

  indartSahaToplamHesapla();
}

/* ISO 14001 functions */
function iso14001SureHesapla() {
  var iso1400115varyok = $('#iso1400115varyok').val();
  if (iso1400115varyok === '1') {
    var rg = $('#riskgrubu14').val();
    var calsay = $('#toplamcalisansayisi').val();

    var postData = 'rg=' + rg + '&calsay=' + calsay;
    var formURL = $('#iso14001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso14001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso1400115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip14001').attr('title', result['tooltip']);
        $('#spantip14001').text(result['tooltip']);
        $('#iso14001hamsure').val(result['sonuc']);
        $('#iso14001kalansure').val(result['sonuc']);
        $('#iso14001a1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso14001a2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso14001gsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#iso14001ybsure').val(parseFloat(result['ybsure']).toFixed(1));

        indartHesapla14001();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso14001SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartHesapla14001() {
  var form = document.getElementById('write14001IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso14001hamsure').val());
  var artimax = 30;
  var eksimax = -30;
  var totoran14001 = $('#totoran14001');

  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.substring(0, 15) === 'chb_indart14001') {
      if (form.elements[i].checked === true) {
        oran += parseFloat(form.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("14001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran14001.removeClass('bg-primary');
    totoran14001.removeClass('bg-danger');
    totoran14001.addClass('bg-success');
    $('#indart14001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran14001.removeClass('bg-primary');
    totoran14001.removeClass('bg-success');
    totoran14001.removeClass('bg-danger');
    $('#indart14001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran14001.removeClass('bg-primary');
    totoran14001.removeClass('bg-danger');
    totoran14001.removeClass('bg-success');
    totoran14001.addClass('bg-success');
    $('#indart14001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran14001.removeClass('bg-primary');
    totoran14001.removeClass('bg-success');
    totoran14001.removeClass('bg-danger');
    totoran14001.addClass('bg-danger');
    $('#indart14001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran14001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);

  kalansure = ana + miktar;
  if (miktar === 0) {
    // console.log("14001 ind oran:::" + oran + ":::miktar:::" + miktar);
    $('#iso14001indart').val(miktar.toFixed(1));
    $('#iso14001azartsure').val(ana.toFixed(1));
    $('#iso14001kalansure').val(ana.toFixed(1));
  } else {
    $('#iso14001indart').val(miktar.toFixed(1));
    $('#iso14001azartsure').val(kalansure.toFixed(1));
    $('#iso14001kalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso14001a1sure').val(a1sure);
    $('#iso14001a2sure').val(a2sure);
    $('#iso14001gsure').val(gsure);
    $('#iso14001ybsure').val(ybsure);
  }

  indartToplamHesapla();
}

/* ISO 45001 functions */
function iso45001SureHesapla() {
  var iso4500118varyok = $('#iso4500118varyok').val();
  if (iso4500118varyok === '1') {
    var rg = $('#riskgrubu45').val();
    var calsay = $('#toplamcalisansayisi').val();

    var postData = 'rg=' + rg + '&calsay=' + calsay;
    var formURL = $('#iso45001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso14001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso1400115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip45001').attr('title', result['tooltip']);
        $('#spantip45001').text(result['tooltip']);
        $('#iso45001hamsure').val(result['sonuc']);
        $('#iso45001kalansure').val(result['sonuc']);
        $('#iso45001a1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso45001a2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso45001gsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#iso45001ybsure').val(parseFloat(result['ybsure']).toFixed(1));

        indartHesapla45001();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso45001SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartHesapla45001() {
  var form = document.getElementById('write45001IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso45001hamsure').val());
  var artimax = 30;
  var eksimax = -30;
  var totoran45001 = $('#totoran45001');

  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.substring(0, 15) === 'chb_indart45001') {
      if (form.elements[i].checked === true) {
        oran += parseFloat(form.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("45001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-danger');
    totoran45001.addClass('bg-success');
    $('#indart45001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-success');
    totoran45001.removeClass('bg-danger');
    $('#indart45001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-danger');
    totoran45001.removeClass('bg-success');
    totoran45001.addClass('bg-success');
    $('#indart45001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-success');
    totoran45001.removeClass('bg-danger');
    totoran45001.addClass('bg-danger');
    $('#indart45001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran45001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);
  // console.log("45001 ind oran:::" + oran + ":::ana:::" + ana + ":::miktar:::" + miktar);

  kalansure = ana + miktar;
  if (miktar === 0) {
    $('#iso45001indart').val(miktar.toFixed(1));
    $('#iso45001azartsure').val(ana.toFixed(1));
    $('#iso45001kalansure').val(ana.toFixed(1));
  } else {
    $('#iso45001indart').val(miktar.toFixed(1));
    $('#iso45001azartsure').val(kalansure.toFixed(1));
    $('#iso45001kalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso45001a1sure').val(a1sure);
    $('#iso45001a2sure').val(a2sure);
    $('#iso45001gsure').val(gsure);
    $('#iso45001ybsure').val(ybsure);
  }

  indartToplamHesapla();
}

function iso45001SahaSureHesapla(subeno) {
  var iso4500118varyok = $('#iso4500118varyok').val();
  if (iso4500118varyok === '1') {
    var rg = $('#riskgrubu45').val();

    var calsay = $('#sube'+subeno+'calsay').val();

    var postData = 'rg=' + rg + '&calsay=' + calsay;
    var formURL = $('#iso45001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso14001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso1400115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip45001' + subeno).attr('title', result['tooltip']);
        $('#spantip45001' + subeno).text(result['tooltip']);
        $('#iso45001hamsure' + subeno).val(result['sonuc']);
        $('#iso45001kalansure' + subeno).val(result['sonuc']);
        $('#iso45001a1sure' + subeno).val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso45001a2sure' + subeno).val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso45001gsure' + subeno).val(parseFloat(result['gsure']).toFixed(1));
        $('#iso45001ybsure' + subeno).val(parseFloat(result['ybsure']).toFixed(1));

        indartSahaHesapla45001(subeno);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso45001SahaSureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartSahaHesapla45001(subeno) {
  var form = document.getElementById('write45001IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso45001hamsure' + subeno).val());
  var artimax = 30;
  var eksimax = -30;
  var totoran45001 = $('#totoran45001');

  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.substring(0, 15) === 'chb_indart45001') {
      if (form.elements[i].checked === true) {
        oran += parseFloat(form.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("45001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-danger');
    totoran45001.addClass('bg-success');
    $('#indart45001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-success');
    totoran45001.removeClass('bg-danger');
    $('#indart45001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-danger');
    totoran45001.removeClass('bg-success');
    totoran45001.addClass('bg-success');
    $('#indart45001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran45001.removeClass('bg-primary');
    totoran45001.removeClass('bg-success');
    totoran45001.removeClass('bg-danger');
    totoran45001.addClass('bg-danger');
    $('#indart45001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran45001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);
  // console.log("45001 ind oran:::" + oran + ":::ana:::" + ana + ":::miktar:::" + miktar);

  kalansure = ana + miktar;
  if (miktar === 0) {
    $('#iso45001indart' + subeno).val(miktar.toFixed(1));
    $('#iso45001azartsure' + subeno).val(ana.toFixed(1));
    $('#iso45001kalansure' + subeno).val(ana.toFixed(1));
  } else {
    $('#iso45001indart' + subeno).val(miktar.toFixed(1));
    $('#iso45001azartsure' + subeno).val(kalansure.toFixed(1));
    $('#iso45001kalansure' + subeno).val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso45001a1sure' + subeno).val(a1sure);
    $('#iso45001a2sure' + subeno).val(a2sure);
    $('#iso45001gsure' + subeno).val(gsure);
    $('#iso45001ybsure' + subeno).val(ybsure);
  }

  indartSahaToplamHesapla();
  // indartToplamHesapla();
}

/* ISO 50001 functions */
function iso50001SureHesapla() {
  var iso5000118varyok = $('#iso5000118varyok').val();
  if (iso5000118varyok === '1') {

    var yillikenerjituketimi = $('#yillikenerjituketimi').val();
    var enerjikaynaksayisi = $('#enerjikaynaksayisi').val();
    var oeksayisi = $('#oeksayisi').val();
    var rg = $('#riskgrubu45').val();
    var calsay = $('#enyscalisansayisi').val();

    var postData = 'calsay=' + calsay + '&yet=' + yillikenerjituketimi.toString() + '&keks=' + enerjikaynaksayisi.toString() + '&oeks=' + oeksayisi.toString();

    var formURL = $('#iso50001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso14001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso1400115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip50001').attr('title', result['tooltip']);
        $('#spantip50001').text(result['tooltip']);
        $('#iso50001hamsure').val(result['sonuc']);
        $('#iso50001kalansure').val(result['sonuc']);
        $('#iso50001a1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso50001a2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso50001gsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#iso50001ybsure').val(parseFloat(result['ybsure']).toFixed(1));

        indartHesapla50001();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso50001SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartHesapla50001() {
  var form = document.getElementById('write50001IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso50001hamsure').val());
  var artimax = 30;
  var eksimax = -30;
  var totoran50001 = $('#totoran50001');

  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.substring(0, 15) === 'chb_indart50001') {
      if (form.elements[i].checked === true) {
        oran += parseFloat(form.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("50001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran50001.removeClass('bg-primary');
    totoran50001.removeClass('bg-danger');
    totoran50001.addClass('bg-success');
    $('#indart50001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran50001.removeClass('bg-primary');
    totoran50001.removeClass('bg-success');
    totoran50001.removeClass('bg-danger');
    $('#indart50001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran50001.removeClass('bg-primary');
    totoran50001.removeClass('bg-danger');
    totoran50001.removeClass('bg-success');
    totoran50001.addClass('bg-success');
    $('#indart50001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran50001.removeClass('bg-primary');
    totoran50001.removeClass('bg-success');
    totoran50001.removeClass('bg-danger');
    totoran50001.addClass('bg-danger');
    $('#indart50001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran50001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);
  // console.log("50001 ind oran:::" + oran + ":::miktar:::" + miktar);

  kalansure = ana + miktar;
  if (miktar === 0) {
    $('#iso50001indart').val(miktar.toFixed(1));
    $('#iso50001azartsure').val(ana.toFixed(1));
    $('#iso50001kalansure').val(ana.toFixed(1));
  } else {
    $('#iso50001indart').val(miktar.toFixed(1));
    $('#iso50001azartsure').val(kalansure.toFixed(1));
    $('#iso50001kalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso50001a1sure').val(a1sure);
    $('#iso50001a2sure').val(a2sure);
    $('#iso50001gsure').val(gsure);
    $('#iso50001ybsure').val(ybsure);
  }

  indartToplamHesapla();
}

/* ISO 27001 functions */
function iso27001SureHesapla() {
  var iso27001varyok = $('#iso27001varyok').val();
  if (iso27001varyok === '1') {
    var calsay = $('#toplamcalisansayisi').val();

    var postData = 'calsay=' + calsay;
    var formURL = $('#iso27001SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso9001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso900115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip27001').attr('title', result['tooltip']);
        $('#spantip27001').text(result['tooltip']);
        $('#iso27001hamsure').val(result['sonuc']);
        $('#iso27001kalansure').val(result['sonuc']);
        $('#iso27001a1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso27001a2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso27001gsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#iso27001ybsure').val(parseFloat(result['ybsure']).toFixed(1));

        $('#modal27001indart').modal('show');

        // indartHesapla27001();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso27001SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

var isFaktor = 0;
var btFaktor = 0;

function isFaktorEtkiHesapla(id, value) {
  let $inp1 = $('#isturu1').is(':checked') ? $('#isturu1').val() : $('#isturu2').is(':checked') ? $('#isturu2').val() : $('#isturu3').is(':checked') ? $('#isturu3').val() : 0;
  let $inp2 = $('#prosesler1').is(':checked') ? $('#prosesler1').val() : $('#prosesler2').is(':checked') ? $('#prosesler2').val() : $('#prosesler3').is(':checked') ? $('#prosesler3').val() : 0;
  let $inp3 = $('#ysolusmaseviyesi1').is(':checked') ? $('#ysolusmaseviyesi1').val() : $('#ysolusmaseviyesi2').is(':checked') ? $('#ysolusmaseviyesi2').val() : $('#ysolusmaseviyesi3').is(':checked') ? $('#ysolusmaseviyesi3').val() : 0;
  isFaktor = parseInt($inp1) + parseInt($inp2) + parseInt($inp3);
  $('#iskartoplam').html(isFaktor);
  // console.log("isFaktorEtkiHesapla::" + isFaktor);
}

function btFaktorEtkiHesapla(id, value) {
  let $inp1 = $('#btaltyapi1').is(':checked') ? $('#btaltyapi1').val() : $('#btaltyapi2').is(':checked') ? $('#btaltyapi2').val() : $('#btaltyapi3').is(':checked') ? $('#btaltyapi3').val() : 0;
  let $inp2 = $('#diskaynak1').is(':checked') ? $('#diskaynak1').val() : $('#diskaynak2').is(':checked') ? $('#diskaynak2').val() : $('#diskaynak3').is(':checked') ? $('#diskaynak3').val() : 0;
  let $inp3 = $('#bilgisistemgelisimi1').is(':checked') ? $('#bilgisistemgelisimi1').val() : $('#bilgisistemgelisimi2').is(':checked') ? $('#bilgisistemgelisimi2').val() : $('#bilgisistemgelisimi3').is(':checked') ? $('#bilgisistemgelisimi3').val() : 0;
  btFaktor = parseInt($inp1) + parseInt($inp2) + parseInt($inp3);
  $('#btkartoplam').html(btFaktor);
  // console.log("btFaktorEtkiHesapla::" + btFaktor);
}

function bgysFaktorEtkiHesapla() {
  var postData = 'isFaktor=' + isFaktor + '&btFaktor=' + btFaktor;
  var formURL = $('#bgysFaktorDenetimEtkisiRoute').val();
  // console.log(postData);
  $.ajax({
    url: formURL,
    type: 'GET',
    data: postData,
    success: function(html) {
      if (html === -100 || html === 'err..') {
        alert('bgysFaktorEtkiHesapla::indirim/arttırım yüzdeliği lınamadı...');
        return false;
      } else {
        $('#totoran27001').val(html);

        indartHesapla27001();
      }
    },
    failure: function() {
      console.log('bgysFaktorEtkiHesapla::hata oldu hesaplanamadı...');
    }
  });
}

function indartHesapla27001() {
  var totoran27001 = $('#totoran27001');
  var oran = parseFloat(totoran27001.val().replace('%+-', ''));
  var ana = parseFloat($('#iso27001hamsure').val());
  var artimax = 100;
  var eksimax = -30;

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("27001 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran27001.removeClass('bg-primary');
    totoran27001.removeClass('bg-danger');
    totoran27001.addClass('bg-success');
    $('#indart27001varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran27001.removeClass('bg-primary');
    totoran27001.removeClass('bg-success');
    totoran27001.removeClass('bg-danger');
    $('#indart27001varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran27001.removeClass('bg-primary');
    totoran27001.removeClass('bg-danger');
    totoran27001.removeClass('bg-success');
    totoran27001.addClass('bg-success');
    $('#indart27001varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran27001.removeClass('bg-primary');
    totoran27001.removeClass('bg-success');
    totoran27001.removeClass('bg-danger');
    totoran27001.addClass('bg-danger');
    $('#indart27001varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran27001.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);
  // console.log("indartHesapla27001 ind oran:::" + oran + ":::ana:::" + ana + ":::miktar:::" + miktar);

  kalansure = ana + miktar;
  if (miktar === 0) {
    $('#iso27001indart').val(miktar.toFixed(1));
    $('#iso27001azartsure').val(ana.toFixed(1));
    $('#iso27001kalansure').val(ana.toFixed(1));
  } else {
    $('#iso27001indart').val(miktar.toFixed(1));
    $('#iso27001azartsure').val(kalansure.toFixed(1));
    $('#iso27001kalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso27001a1sure').val(a1sure);
    $('#iso27001a2sure').val(a2sure);
    $('#iso27001gsure').val(gsure);
    $('#iso27001ybsure').val(ybsure);
  }

  toplamHesapla();
}

/* ISO 22000 functions */
function iso22000SureHesapla() {
  var iso2200018varyok = $('#iso2200018varyok').val();
  if (iso2200018varyok === '1') {
    var calsay = $('#toplamcalisansayisi').val();
    var cat = $('#gizlikat').val();
    var bb = $('#gizlikatbb').val();
    var cc = $('#gizlikatcc').val();
    var haccpsayisi = $('#haccpcalismasisayisi').val();
    // var mysvarmi = ($('#chb_mysvarmi').is(':checked') === true) ? 'EVET' : 'HAYIR'; //$("#chb_mysvarmi").val();
    var sahasayisi = $('#sahasayisi22').val();

    var postData = 'calsay=' + calsay + '&cat=' + cat + '&bb=' + bb + '&cc=' + cc + '&haccpsayisi=' + haccpsayisi + '&sahasayisi=' + sahasayisi;

    var formURL = $('#iso22000SureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso14001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso1400115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltip22000').attr('title', result['tooltip']);
        $('#spantip22000').text(result['tooltip']);
        $('#iso22000hamsure').val(result['sonuc']);
        $('#iso22000kalansure').val(result['sonuc']);
        $('#iso22000a1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#iso22000a2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#iso22000gsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#iso22000ybsure').val(parseFloat(result['ybsure']).toFixed(1));

        indartHesapla22000();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[iso22000SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartHesapla22000() {
  var form = document.getElementById('write22000IndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#iso22000hamsure').val());
  var artimax = 30;
  var eksimax = -30;
  var totoran22000 = $('#totoran22000');

  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.substring(0, 15) === 'chb_indart22000') {
      if (form.elements[i].checked === true) {
        oran += parseFloat(form.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("22000 ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoran22000.removeClass('bg-primary');
    totoran22000.removeClass('bg-danger');
    totoran22000.addClass('bg-success');
    $('#indart22000varmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoran22000.removeClass('bg-primary');
    totoran22000.removeClass('bg-success');
    totoran22000.removeClass('bg-danger');
    $('#indart22000varmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoran22000.removeClass('bg-primary');
    totoran22000.removeClass('bg-danger');
    totoran22000.removeClass('bg-success');
    totoran22000.addClass('bg-success');
    $('#indart22000varmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoran22000.removeClass('bg-primary');
    totoran22000.removeClass('bg-success');
    totoran22000.removeClass('bg-danger');
    totoran22000.addClass('bg-danger');
    $('#indart22000varmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoran22000.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);
  // console.log("22000 ind oran:::" + oran + ":::miktar:::" + miktar);

  kalansure = ana + miktar;
  if (miktar === 0) {
    $('#iso22000indart').val(miktar.toFixed(1));
    $('#iso22000azartsure').val(ana.toFixed(1));
    $('#iso22000kalansure').val(ana.toFixed(1));
  } else {
    $('#iso22000indart').val(miktar.toFixed(1));
    $('#iso22000azartsure').val(kalansure.toFixed(1));
    $('#iso22000kalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#iso22000a1sure').val(a1sure);
    $('#iso22000a2sure').val(a2sure);
    $('#iso22000gsure').val(gsure);
    $('#iso22000ybsure').val(ybsure);
  }

  indartToplamHesapla();
}

/* ISO oicsmiic functions */
function isoOicSmiicSureHesapla() {
  var helalvaryok = $('#helalvaryok').val();
  var oicsmiik6varyok = $('#oicsmiik6varyok').val();
  var oicsmiik9varyok = $('#oicsmiik9varyok').val();
  var oicsmiik171varyok = $('#oicsmiik171varyok').val();
  var oicsmiik23varyok = $('#oicsmiik23varyok').val();
  var oicsmiik24varyok = $('#oicsmiik24varyok').val();
  if (helalvaryok === '1' || oicsmiik6varyok === '1' || oicsmiik9varyok === '1' || oicsmiik171varyok === '1' || oicsmiik23varyok === '1' || oicsmiik24varyok === '1') {
    var calsay = $('#toplamcalisansayisi').val();
    var cat = $('#gizlioickat').val();
    var bb = $('#gizlikatbb').val();
    var cc = $('#gizlikatcc').val();
    var haccpsayisi = parseInt($('#haccpcalismasisayisismiic').val());
    var cck = $('#oicsmiickk').val();
    var pv = $('#helalurunsayisi').val();
    var alansayisi = $('#oic_sahasayisi22').val();
    var havuzsayisi = $('#havuzsayisi').val();
    var mutfaksayisi = $('#mutfaksayisi').val();
    var odasayisi = $('#odasayisi').val();
    var hizmetkategorisi = $('#hizmetkategorisi').val();
    var aracsayisi = $('#aracsayisi').val();

    var postData = 'calsay=' + calsay + '&cat=' + cat + '&bb=' + bb + '&cc=' + cc + '&haccpsayisi=' + haccpsayisi + '&cck=' + cck + '&pv=' + pv + '&sahasayisi=' + alansayisi + '&havuzsayisi=' + havuzsayisi + '&mutfaksayisi=' + mutfaksayisi + '&odasayisi=' + odasayisi + '&hizmetkategorisi=' + hizmetkategorisi + '&aracsayisi=' + aracsayisi;

    var formURL = $('#isoOicSmiicSureHesaplaRoute').val();

    // console.log("formKaydet::route:: ");
    // console.log("iso14001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso1400115varyok);
    $.ajax({
      url: formURL,
      type: 'GET',
      data: postData,
      success: function(html) {
        var result = $.parseJSON(html);
        $('#tooltipoicsmiic').attr('title', result['tooltip']);
        $('#spantipoicsmiic').text(result['tooltip']);
        $('#oicsmiichamsure').val(result['sonuc']);
        $('#oicsmiickalansure').val(result['sonuc']);
        $('#oicsmiica1sure').val(parseFloat(result['a1sure']).toFixed(1));
        $('#oicsmiica2sure').val(parseFloat(result['a2sure']).toFixed(1));
        $('#oicsmiicgsure').val(parseFloat(result['gsure']).toFixed(1));
        $('#oicsmiicybsure').val(parseFloat(result['ybsure']).toFixed(1));

        indartHesaplaOicsmiic();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        $('#formkaydetsonucerror').html('[isoOicSmiicSureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
        // window.console.log("formKaydet: " + formURL + "?" + postData);
        $('#myModalError').modal('show');
      }
    });

  }
}

function indartHesaplaOicsmiic() {
  var form = document.getElementById('writeSmiicIndArt-form');
  var oran = parseFloat(0);
  var ana = parseFloat($('#oicsmiichamsure').val());
  var artimax = 30;
  var eksimax = -30;
  var totoranoicsmiic = $('#totoranoicsmiic');

  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.substring(0, 15) === 'chb_indartsmiic') {
      if (form.elements[i].checked === true) {
        oran += parseFloat(form.elements[i].value);
      }
    }
  }

  oran = parseFloat(oran);
  if (oran <= eksimax) {
    oran = eksimax;
  }
  if (oran >= artimax) {
    oran = artimax;
  }
  // console.log("oicsmiic ind oran:::" + oran + ":::ana:::" + ana);
  if (oran > 0 && oran <= artimax) {
    totoranoicsmiic.removeClass('bg-primary');
    totoranoicsmiic.removeClass('bg-danger');
    totoranoicsmiic.addClass('bg-success');
    $('#indartoicsmiicvarmi').val('1');
    // console.log("1:::" + eksimax);
  }
  if (oran === 0) {
    totoranoicsmiic.removeClass('bg-primary');
    totoranoicsmiic.removeClass('bg-success');
    totoranoicsmiic.removeClass('bg-danger');
    $('#indartoicsmiicvarmi').val('0');
    // console.log("2:::" + eksimax);
  }

  if (oran < 0 && oran >= eksimax) {
    totoranoicsmiic.removeClass('bg-primary');
    totoranoicsmiic.removeClass('bg-danger');
    totoranoicsmiic.removeClass('bg-success');
    totoranoicsmiic.addClass('bg-success');
    $('#indartoicsmiicvarmi').val('1');
    // console.log("3:::" + eksimax);
  }
  if (oran > artimax || oran < eksimax) {
    totoranoicsmiic.removeClass('bg-primary');
    totoranoicsmiic.removeClass('bg-success');
    totoranoicsmiic.removeClass('bg-danger');
    totoranoicsmiic.addClass('bg-danger');
    $('#indartoicsmiicvarmi').val('1');

    oran = (oran < 0) ? oran = eksimax : oran = artimax;
    // console.log("4:::" + eksimax);
  }

  totoranoicsmiic.val('%' + oran.toString());

  var miktar = parseFloat((ana * oran / 100).toFixed(1));
  var kalansure = parseFloat(0);
  // console.log("oicsmiic ind oran:::" + oran + ":::miktar:::" + miktar);

  kalansure = ana + miktar;
  if (miktar === 0) {
    $('#oicsmiicindart').val(miktar.toFixed(1));
    $('#oicsmiicazartsure').val(ana.toFixed(1));
    $('#oicsmiickalansure').val(ana.toFixed(1));
  } else {
    $('#oicsmiicindart').val(miktar.toFixed(1));
    $('#oicsmiicazartsure').val(kalansure.toFixed(1));
    $('#oicsmiickalansure').val(kalansure.toFixed(1));
  }

  if (kalansure > 0) {
    var a1sure = parseFloat(kalansure * 30 / 100).toFixed(1);
    var a2sure = parseFloat(kalansure * 70 / 100).toFixed(1);
    var gsure = parseFloat(kalansure / 3).toFixed(1);
    var ybsure = parseFloat(kalansure * 2 / 3).toFixed(1);

    $('#oicsmiica1sure').val(a1sure);
    $('#oicsmiica2sure').val(a2sure);
    $('#oicsmiicgsure').val(gsure);
    $('#oicsmiicybsure').val(ybsure);
  }

  indartToplamHesapla();
}

function indartHesaplaEntegreYenile() {
  indartHesaplaEntegre();
  indartHesaplaEntegre();
}

function indartHesaplaEntegre() {
  var iso9001 = $('#iso900115varyok').val() === '1',
    iso14001 = $('#iso1400115varyok').val() === '1',
    iso22000 = $('#iso2200018varyok').val() === '1',
    iso45001 = $('#iso4500118varyok').val() === '1',
    iso50001 = $('#iso5000118varyok').val() === '1',
    iso27001 = $('#iso27001varyok').val() === '1',
    oicsmiik = $('#helalvaryok').val() === '1',
    oicsmiik6 = $('#oicsmiik6varyok').val() === '1',
    oicsmiik9 = $('#oicsmiik9varyok').val() === '1',
    oicsmiik171 = $('#oicsmiik171varyok').val() === '1',
    oicsmiik23 = $('#oicsmiik23varyok').val() === '1',
    oicsmiik24 = $('#oicsmiik24varyok').val() === '1',
    isOicsmiic = (oicsmiik || oicsmiik6 || oicsmiik9 || oicsmiik171 || oicsmiik23 || oicsmiik24) ?? false;
  var entindvarmi = $('#indartentvarmi').val() === '1';
  var sistemsay = parseFloat(0);
  var totoranEntegre = $('#totoranEntegre');

  var ana9001 = (iso9001) ? parseFloat($('#iso9001azartsure').val()) : parseFloat(0);
  var ana14001 = (iso14001) ? parseFloat($('#iso14001azartsure').val()) : parseFloat(0);
  var ana45001 = (iso45001) ? parseFloat($('#iso45001azartsure').val()) : parseFloat(0);
  var ana50001 = (iso50001) ? parseFloat($('#iso50001azartsure').val()) : parseFloat(0);
  var ana27001 = (iso27001) ? parseFloat($('#iso27001azartsure').val()) : parseFloat(0);
  var ana22000 = (iso22000) ? parseFloat($('#iso22000azartsure').val()) : parseFloat(0);
  var anaOicsmiic = (oicsmiik || oicsmiik6 || oicsmiik9 || oicsmiik171 || oicsmiik23 || oicsmiik24) ? parseFloat($('#oicsmiicazartsure').val()) : parseFloat(0);

  if (iso9001) {
    sistemsay++;
  }
  if (iso14001) {
    sistemsay++;
  }
  if (iso45001) {
    sistemsay++;
  }
  if (iso50001) {
    sistemsay++;
  }
  if (iso27001) {
    sistemsay++;
  }
  if (iso22000) {
    sistemsay++;
  }
  if (isOicsmiic) {
    sistemsay++;
  }
  var formplan = document.getElementById('writeEntegreIndArt-form');
  var xekseni = parseFloat(0);
  var yekseni = parseFloat(0);
  var ana = parseFloat($('#toplamazart').val());
  var denetcisay = $('#denetcisay').val();

  var i;
  for (i = 0; i < formplan.length; i++) {
    if (formplan.elements[i].type === 'checkbox' && formplan.elements[i].name.substring(0, 17) === 'chb_indartentegre') {
      if (formplan.elements[i].checked === true) {
        yekseni += parseFloat(formplan.elements[i].value);
      }
    }
  }

  var pay = 0;
  var payda = 0;
  for (var j = 0; j < densisyet.length; j++) {
    var say1 = densisyet[j];
    // console.log('say1: ' + say1);

    pay += say1 - 1;
  }
  pay = pay * 100;
  payda = denetcisay * (sistemsay - 1);
  xekseni = parseFloat(pay / payda).toFixed(0);

  // console.log("pay: " + pay);
  // console.log("payda: " + payda);
  // console.log("Kabiliyeti(x): " + xekseni);
  // console.log("entegre duzeyi(y): " + yekseni);

  getEntegreOran(purifyEksen(xekseni), purifyEksen(yekseni));

  totoranEntegre.val('%' + duzey.toString());

  // console.log("ana: " + ana);
  // console.log("xekseni: " + purifyEksen(xekseni));
  // console.log("yekseni: " + purifyEksen(yekseni));
  // console.log("entegre duzeyi: " + duzey);

  if (duzey >= 0 && duzey <= 20) {
    totoranEntegre.removeClass('bg-primary');
    totoranEntegre.removeClass('bg-danger');
    totoranEntegre.addClass('bg-success');
    $('#indartentvarmi').val('1');
  }
  if (duzey === 0) {
    totoranEntegre.removeClass('bg-success');
    totoranEntegre.removeClass('bg-danger');
    totoranEntegre.addClass('bg-primary');
    $('#indartentvarmi').val('0');
  }

  var miktar = (-1) * parseFloat((ana * duzey / 100).toFixed(1));
  var miktar9001 = parseFloat((ana9001 * duzey / 100).toFixed(1));
  var miktar14001 = parseFloat((ana14001 * duzey / 100).toFixed(1));
  var miktar45001 = parseFloat((ana45001 * duzey / 100).toFixed(1));
  var miktar50001 = parseFloat((ana50001 * duzey / 100).toFixed(1));
  var miktar27001 = parseFloat((ana27001 * duzey / 100).toFixed(1));
  var miktar22000 = parseFloat((ana22000 * duzey / 100).toFixed(1));
  var miktarOicsmiic = parseFloat((anaOicsmiic * duzey / 100).toFixed(1));
  var kalansure = parseFloat(0);
  $('#denetimentegreindirim').val(miktar.toFixed(1));

  // console.log("ana9001: " + ana900115);
  // console.log("ana14001: " + ana1400115);
  //  console.log("miktar22000: " + miktar22000);
  //  console.log("miktar50001: " + miktar50001);
  // console.log("kalansure: " + kalansure);
  // console.log("miktar: " + miktar);
  kalansure = ana + miktar;
  // console.log("kalansure: " + kalansure);
  if (miktar === 0) {
    $('#toplamkalansure').val(ana.toFixed(1));
    $('#iso9001entindart').val(ana9001.toFixed(1));
    $('#iso14001entindart').val(ana14001.toFixed(1));
    $('#iso45001entindart').val(ana45001.toFixed(1));
    $('#iso50001entindart').val(ana50001.toFixed(1));
    $('#iso27001entindart').val(ana27001.toFixed(1));
    $('#iso22000entindart').val(ana22000.toFixed(1));
    $('#oicsmiicentindart').val(anaOicsmiic.toFixed(1));

    $('#iso9001kalansure').val(ana9001.toFixed(1));
    $('#iso14001kalansure').val(ana14001.toFixed(1));
    $('#iso45001kalansure').val(ana45001.toFixed(1));
    $('#iso50001kalansure').val(ana50001.toFixed(1));
    $('#iso27001kalansure').val(ana27001.toFixed(1));
    $('#iso22000kalansure').val(ana22000.toFixed(1));
    $('#oicsmiickalansure').val(anaOicsmiic.toFixed(1));
  } else {
    $('#toplamkalansure').val(kalansure.toFixed(1));
    $('#iso9001entindart').val((miktar9001).toFixed(1));
    $('#iso14001entindart').val((miktar14001).toFixed(1));
    $('#iso45001entindart').val((miktar45001).toFixed(1));
    $('#iso50001entindart').val((miktar50001).toFixed(1));
    $('#iso27001entindart').val((miktar27001).toFixed(1));
    $('#iso22000entindart').val((miktar22000).toFixed(1));
    $('#oicsmiicentindart').val((miktarOicsmiic).toFixed(1));

    $('#iso9001kalansure').val((ana9001 - miktar9001).toFixed(1));
    $('#iso14001kalansure').val((ana14001 - miktar14001).toFixed(1));
    $('#iso45001kalansure').val((ana45001 - miktar45001).toFixed(1));
    $('#iso50001kalansure').val((ana50001 - miktar50001).toFixed(1));
    $('#iso27001kalansure').val((ana27001 - miktar27001).toFixed(1));
    $('#iso22000kalansure').val((ana22000 - miktar22000).toFixed(1));
    $('#oicsmiickalansure').val((anaOicsmiic - miktarOicsmiic).toFixed(1));
  }

  toplamHesapla();
  // indirArttirSebepler();
}

function getEntegreOran(x, y) {
  var formURL = $('#entegreDuzeyleriRoute').val();

  $.ajax({
    type: 'GET',
    url: formURL,
    cache: false,
    success: function(html) {
      // console.log("getEntegreOran::jsondata: " + jsondata);
      var result = $.parseJSON(html);
      $.each(result, function(k, v) {
        if (k === (x + '-' + y)) {
          $('#totoranEntegre').val(v);
          duzey = v;
        }
      });
    }
  });

}

function purifyEksen(eks) {
  var eksen = eks;
  if (eks > 0 && eks < 20) {
    eksen = 0;
  }
  if (eks > 20 && eks < 40) {
    eksen = 40;
  }
  if (eks > 40 && eks < 60) {
    eksen = 60;
  }
  if (eks > 60 && eks < 80) {
    eksen = 80;
  }
  if (eks > 80 && eks < 100) {
    eksen = 100;
  }
  if (eks === 100) {
    eksen = 100;
  }
  if (eks > 100) {
    eksen = 100;
  }
  return eksen;
}

function indartToplamHesapla() {
  var iso9001 = $('#iso900115varyok').val() === '1',
    iso14001 = $('#iso1400115varyok').val() === '1',
    iso22000 = $('#iso2200018varyok').val() === '1',
    iso45001 = $('#iso4500118varyok').val() === '1',
    iso50001 = $('#iso5000118varyok').val() === '1',
    // iso27001 = $('#iso27001varyok').val() === "1",
    oicsmiik = $('#helalvaryok').val() === '1',
    oicsmiik6 = $('#oicsmiik6varyok').val() === '1',
    oicsmiik9 = $('#oicsmiik9varyok').val() === '1',
    oicsmiik171 = $('#oicsmiik171varyok').val() === '1',
    oicsmiik23 = $('#oicsmiik23varyok').val() === '1',
    oicsmiik24 = $('#oicsmiik24varyok').val() === '1';

  var ana9001 = (iso9001) ? parseFloat($('#iso9001hamsure').val()) : parseFloat(0);
  var ana14001 = (iso14001) ? parseFloat($('#iso14001hamsure').val()) : parseFloat(0);
  var ana45001 = (iso45001) ? parseFloat($('#iso45001hamsure').val()) : parseFloat(0);
  var ana50001 = (iso50001) ? parseFloat($('#iso50001hamsure').val()) : parseFloat(0);
  // var ana27001 = (iso27001) ? parseFloat($("#iso27001hamsure").val()) : parseFloat(0);
  var ana22000 = (iso22000) ? parseFloat($('#iso22000hamsure').val()) : parseFloat(0);
  var anaOicsmiic = (oicsmiik || oicsmiik6 || oicsmiik9 || oicsmiik171 || oicsmiik23 || oicsmiik24) ? parseFloat($('#oicsmiichamsure').val()) : parseFloat(0);

  // console.log("ana9001: " + ana9001 + " ana14001: " + ana14001 + " ana45001: " + ana45001 + " ana50001: " + ana50001 + " ana27001: " + ana27001 + " ana22000: " + ana22000 + " anaOicsmiic: " + anaOicsmiic);

  var topind9001 = parseFloat(0);
  var topart9001 = parseFloat(0);
  var topind14001 = parseFloat(0);
  var topart14001 = parseFloat(0);
  var topind45001 = parseFloat(0);
  var topart45001 = parseFloat(0);
  var topind50001 = parseFloat(0);
  var topart50001 = parseFloat(0);
  var topart22000 = parseFloat(0);
  var topindOicsmiic = parseFloat(0);
  var topartOicsmiic = parseFloat(0);
  // var topind27001 = (iso27001) ? parseFloat($("#iso27001indart").val()) : parseFloat(0);
  // var topart27001 = (iso27001) ? parseFloat($("#iso27001azartsure").val()) : parseFloat(0);
  //
  // console.log("ind-art 27001::0::: " + $("#denetimgunarttirilmasi").val());

  var form = document.getElementById('write9001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart9001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind9001 += parseInt(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart9001 += parseInt(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write14001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart14001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind14001 += parseFloat(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart14001 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write45001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart45001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind45001 += parseFloat(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart45001 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write50001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart50001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind50001 += parseFloat(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart50001 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write22000IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart22000')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) > 0) {
          topart22000 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('writeSmiicIndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indartsmiic')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topindOicsmiic += parseInt(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topartOicsmiic += parseFloat(form.elements[i].value);
        }
      }
    }
  }


  topind9001 = parseFloat(topind9001);
  topart9001 = parseFloat(topart9001);
  topind14001 = parseFloat(topind14001);
  topart14001 = parseFloat(topart14001);
  topind45001 = parseFloat(topind45001);
  topart45001 = parseFloat(topart45001);
  topind50001 = parseFloat(topind50001);
  topart50001 = parseFloat(topart50001);
  topart22000 = parseFloat(topart22000);
  topindOicsmiic = parseFloat(topindOicsmiic);
  topartOicsmiic = parseFloat(topartOicsmiic);

  if (topind9001 > 30 || topind9001 < -30) {
    topind9001 = (topind9001 < 0) ? topind9001 = -30 : topind9001 = 30;
  }

  if (topart9001 > 30 || topart9001 < -30) {
    topart9001 = (topart9001 < 0) ? topart9001 = -30 : topart9001 = 30;
  }

  if (topind14001 > 30 || topind14001 < -30) {
    topind14001 = (topind14001 < 0) ? topind14001 = -30 : topind14001 = 30;
  }

  if (topart14001 > 30 || topart14001 < -30) {
    topart14001 = (topart14001 < 0) ? topart14001 = -30 : topart14001 = 30;
  }

  if (topind45001 > 30 || topind45001 < -30) {
    topind45001 = (topind45001 < 0) ? topind45001 = -30 : topind45001 = 30;
  }

  if (topart45001 > 30 || topart45001 < -30) {
    topart45001 = (topart45001 < 0) ? topart45001 = -30 : topart45001 = 30;
  }

  if (topind50001 > 30 || topind50001 < -30) {
    topind50001 = (topind50001 < 0) ? topind50001 = -30 : topind50001 = 30;
  }

  if (topart50001 > 30 || topart50001 < -30) {
    topart50001 = (topart50001 < 0) ? topart50001 = -30 : topart50001 = 30;
  }

  if (topart22000 > 30 || topart22000 < -30) {
    topart22000 = (topart22000 < 0) ? topart22000 = -30 : topart22000 = 30;
  }

  if (topindOicsmiic > 30 || topindOicsmiic < -30) {
    topindOicsmiic = (topindOicsmiic < 0) ? topindOicsmiic = -30 : topindOicsmiic = 30;
  }

  if (topartOicsmiic > 30 || topartOicsmiic < -30) {
    topartOicsmiic = (topartOicsmiic < 0) ? topartOicsmiic = -30 : topartOicsmiic = 30;
  }

  // if (topind27001 > 100 || topind27001 < -30) {
  //   topind27001 = (topind27001 < 0) ? topind27001 = -30 : topind27001 = 100;
  // }
  //
  // if (topart27001 > 100 || topart27001 < -30) {
  //   topart27001 = (topart27001 < 0) ? topart27001 = -30 : topart27001 = 100;
  // }

  var indSonuc9001 = parseFloat((ana9001 * topind9001 / 100).toFixed(1));
  var indSonuc14001 = parseFloat((ana14001 * topind14001 / 100).toFixed(1));
  var indSonuc45001 = parseFloat((ana45001 * topind45001 / 100).toFixed(1));
  var indSonuc50001 = parseFloat((ana50001 * topind50001 / 100).toFixed(1));
  // var indSonuc27001 = parseFloat((ana27001 * topind27001 / 100).toFixed(1));
  var indSonucOicsmiic = parseFloat((anaOicsmiic * topindOicsmiic / 100).toFixed(1));

  var artSonuc9001 = parseFloat((ana9001 * topart9001 / 100).toFixed(1));
  var artSonuc14001 = parseFloat((ana14001 * topart14001 / 100).toFixed(1));
  var artSonuc45001 = parseFloat((ana45001 * topart45001 / 100).toFixed(1));
  var artSonuc50001 = parseFloat((ana50001 * topart50001 / 100).toFixed(1));
  // var artSonuc27001 = parseFloat((ana27001 * topart27001 / 100).toFixed(1));
  var artSonuc22000 = parseFloat((ana22000 * topart22000 / 100).toFixed(1));
  var artSonucOicsmiic = parseFloat((anaOicsmiic * topartOicsmiic / 100).toFixed(1));

  // console.log("ind-art 9001::::: " + topind9001 + " ::::: " + topart9001 + " ::::: " + indSonuc9001 + " ::::: " + artSonuc9001);
  // console.log("ind-art 14001::::: " + topind14001 + " ::::: " + topart14001 + " ::::: " + indSonuc14001 + " ::::: " + artSonuc14001);
  // console.log("ind-art 45001::::: " + topind45001 + " ::::: " + topart45001 + " ::::: " + indSonuc45001 + " ::::: " + artSonuc45001);
  // console.log("ind-art 50001::::: " + topind50001 + " ::::: " + topart50001 + " ::::: " + indSonuc50001 + " ::::: " + artSonuc50001);
  // console.log("ind-art 27001::::: " + ana27001 + " ::::: " + topind27001 + " ::::: " + topart27001 + " ::::: " + indSonuc27001 + " ::::: " + artSonuc27001);
  // console.log("ind-art 22000::::: " + topart22000 + " ::::: " + artSonuc22000);
  // console.log("ind-art smiic::::: " + topindOicsmiic + " ::::: " + topartOicsmiic + " ::::: " + indSonucOicsmiic + " ::::: " + artSonucOicsmiic);

  var ind = indSonuc9001 + indSonuc14001 + indSonuc45001 + indSonuc50001 + indSonucOicsmiic;
  $('#denetimgunazaltilmasi').val(ind.toFixed(1));

  var art = artSonuc9001 + artSonuc14001 + artSonuc45001 + artSonuc50001 + artSonuc22000 + artSonucOicsmiic;
  $('#denetimgunarttirilmasi').val(art.toFixed(1));

  indirArttirSebepler();
  toplamHesapla();
}

function indartSahaToplamHesapla(sube) {
  var iso9001 = $('#iso900115varyok').val() === '1',
    iso14001 = $('#iso1400115varyok').val() === '1',
    iso45001 = $('#iso4500118varyok').val() === '1',
    iso50001 = $('#iso5000118varyok').val() === '1',
    iso27001 = $('#iso27001varyok').val() === "1";

  var ana9001 = (iso9001) ? parseFloat($('#iso9001hamsure' + sube).val()) : parseFloat(0);
  var ana14001 = (iso14001) ? parseFloat($('#iso14001hamsure' + sube).val()) : parseFloat(0);
  var ana45001 = (iso45001) ? parseFloat($('#iso45001hamsure' + sube).val()) : parseFloat(0);
  var ana50001 = (iso50001) ? parseFloat($('#iso50001hamsure' + sube).val()) : parseFloat(0);
  // var ana27001 = (iso27001) ? parseFloat($("#iso27001hamsure").val() + sube) : parseFloat(0);

  // console.log("ana9001: " + ana9001 + " ana14001: " + ana14001 + " ana45001: " + ana45001 + " ana50001: " + ana50001 + " ana27001: " + ana27001 + " ana22000: " + ana22000 + " anaOicsmiic: " + anaOicsmiic);

  var topind9001 = parseFloat(0);
  var topart9001 = parseFloat(0);
  var topind14001 = parseFloat(0);
  var topart14001 = parseFloat(0);
  var topind45001 = parseFloat(0);
  var topart45001 = parseFloat(0);
  var topind50001 = parseFloat(0);
  var topart50001 = parseFloat(0);
  // var topind27001 = (iso27001) ? parseFloat($("#iso27001indart").val()) : parseFloat(0);
  // var topart27001 = (iso27001) ? parseFloat($("#iso27001azartsure").val()) : parseFloat(0);
  //
  // console.log("ind-art 27001::0::: " + $("#denetimgunarttirilmasi").val());

  var form = document.getElementById('write9001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart9001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind9001 += parseInt(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart9001 += parseInt(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write14001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart14001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind14001 += parseFloat(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart14001 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write45001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart45001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind45001 += parseFloat(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart45001 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  form = document.getElementById('write50001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart50001')) {
      if (form.elements[i].checked === true) {
        if (parseFloat(form.elements[i].value) < 0) {
          topind50001 += parseFloat(form.elements[i].value);
        }
        if (parseFloat(form.elements[i].value) > 0) {
          topart50001 += parseFloat(form.elements[i].value);
        }
      }
    }
  }

  topind9001 = parseFloat(topind9001);
  topart9001 = parseFloat(topart9001);
  topind14001 = parseFloat(topind14001);
  topart14001 = parseFloat(topart14001);
  topind45001 = parseFloat(topind45001);
  topart45001 = parseFloat(topart45001);
  topind50001 = parseFloat(topind50001);
  topart50001 = parseFloat(topart50001);

  if (topind9001 > 30 || topind9001 < -30) {
    topind9001 = (topind9001 < 0) ? topind9001 = -30 : topind9001 = 30;
  }

  if (topart9001 > 30 || topart9001 < -30) {
    topart9001 = (topart9001 < 0) ? topart9001 = -30 : topart9001 = 30;
  }

  if (topind14001 > 30 || topind14001 < -30) {
    topind14001 = (topind14001 < 0) ? topind14001 = -30 : topind14001 = 30;
  }

  if (topart14001 > 30 || topart14001 < -30) {
    topart14001 = (topart14001 < 0) ? topart14001 = -30 : topart14001 = 30;
  }

  if (topind45001 > 30 || topind45001 < -30) {
    topind45001 = (topind45001 < 0) ? topind45001 = -30 : topind45001 = 30;
  }

  if (topart45001 > 30 || topart45001 < -30) {
    topart45001 = (topart45001 < 0) ? topart45001 = -30 : topart45001 = 30;
  }

  if (topind50001 > 30 || topind50001 < -30) {
    topind50001 = (topind50001 < 0) ? topind50001 = -30 : topind50001 = 30;
  }

  if (topart50001 > 30 || topart50001 < -30) {
    topart50001 = (topart50001 < 0) ? topart50001 = -30 : topart50001 = 30;
  }

  // if (topind27001 > 100 || topind27001 < -30) {
  //   topind27001 = (topind27001 < 0) ? topind27001 = -30 : topind27001 = 100;
  // }
  //
  // if (topart27001 > 100 || topart27001 < -30) {
  //   topart27001 = (topart27001 < 0) ? topart27001 = -30 : topart27001 = 100;
  // }

  var indSonuc9001 = parseFloat((ana9001 * topind9001 / 100).toFixed(1));
  var indSonuc14001 = parseFloat((ana14001 * topind14001 / 100).toFixed(1));
  var indSonuc45001 = parseFloat((ana45001 * topind45001 / 100).toFixed(1));
  var indSonuc50001 = parseFloat((ana50001 * topind50001 / 100).toFixed(1));
  // var indSonuc27001 = parseFloat((ana27001 * topind27001 / 100).toFixed(1));

  var artSonuc9001 = parseFloat((ana9001 * topart9001 / 100).toFixed(1));
  var artSonuc14001 = parseFloat((ana14001 * topart14001 / 100).toFixed(1));
  var artSonuc45001 = parseFloat((ana45001 * topart45001 / 100).toFixed(1));
  var artSonuc50001 = parseFloat((ana50001 * topart50001 / 100).toFixed(1));
  // var artSonuc27001 = parseFloat((ana27001 * topart27001 / 100).toFixed(1));

  // console.log("ind-art 9001::::: " + topind9001 + " ::::: " + topart9001 + " ::::: " + indSonuc9001 + " ::::: " + artSonuc9001);
  // console.log("ind-art 14001::::: " + topind14001 + " ::::: " + topart14001 + " ::::: " + indSonuc14001 + " ::::: " + artSonuc14001);
  // console.log("ind-art 45001::::: " + topind45001 + " ::::: " + topart45001 + " ::::: " + indSonuc45001 + " ::::: " + artSonuc45001);
  // console.log("ind-art 50001::::: " + topind50001 + " ::::: " + topart50001 + " ::::: " + indSonuc50001 + " ::::: " + artSonuc50001);
  // console.log("ind-art 27001::::: " + ana27001 + " ::::: " + topind27001 + " ::::: " + topart27001 + " ::::: " + indSonuc27001 + " ::::: " + artSonuc27001);

  var ind = indSonuc9001 + indSonuc14001 + indSonuc45001 + indSonuc50001;
  var indm = parseFloat($('#denetimgunazaltilmasi').val());
  $('#denetimgunazaltilmasi').val((indm+ind).toFixed(1));

  var art = artSonuc9001 + artSonuc14001 + artSonuc45001 + artSonuc50001;
  var artm = parseFloat($('#denetimgunarttirilmasi').val());
  $('#denetimgunarttirilmasi').val((artm+art).toFixed(1));

  indirArttirSebepler();
  toplamHesapla();
}

function hesapla() {
  var spnr = $('#sureHesaplaSpinner');
  spnr.show();
  iso9001SureHesapla();
  iso14001SureHesapla();
  iso45001SureHesapla();
  iso50001SureHesapla();
  iso27001SureHesapla();
  iso22000SureHesapla();
  isoOicSmiicSureHesapla();

  var subesayisi = $('#inceleneceksahasayisi').val() //p
  for (var i = 1; i <= subesayisi; i++) {
    iso9001SahaSureHesapla(i);
    iso45001SahaSureHesapla(i);
  }

  // indartToplamHesapla();
  toplamHesapla();
  spnr.hide();

}

function toplamHesapla() {
  var iso9001 = $('#iso900115varyok').val() === '1',
    iso14001 = $('#iso1400115varyok').val() === '1',
    iso22000 = $('#iso2200018varyok').val() === '1',
    iso45001 = $('#iso4500118varyok').val() === '1',
    iso50001 = $('#iso5000118varyok').val() === '1',
    iso27001 = $('#iso27001varyok').val() === '1',
    oicsmiik = $('#helalvaryok').val() === '1',
    oicsmiik6 = $('#oicsmiik6varyok').val() === '1',
    oicsmiik9 = $('#oicsmiik9varyok').val() === '1',
    oicsmiik171 = $('#oicsmiik171varyok').val() === '1',
    oicsmiik23 = $('#oicsmiik23varyok').val() === '1',
    oicsmiik24 = $('#oicsmiik24varyok').val() === '1',
    isOicsmiic = (oicsmiik || oicsmiik6 || oicsmiik9 || oicsmiik171 || oicsmiik23 || oicsmiik24) ?? false;

  var ana = parseFloat(0);
  var indart = parseFloat(0);
  var azart = parseFloat(0);
  var entindart = parseFloat(0);
  var kalan = parseFloat(0);
  var a1sure = parseFloat(0);
  var a2sure = parseFloat(0);
  var gozsure = parseFloat(0);
  var ybsure = parseFloat(0);

  var anasube = parseFloat(0);
  var indartsube = parseFloat(0);
  var azartsube = parseFloat(0);
  var entindartsube = parseFloat(0);
  var kalansube = parseFloat(0);
  var a1suresube = parseFloat(0);
  var a2suresube = parseFloat(0);
  var gozsuresube = parseFloat(0);
  var ybsuresube = parseFloat(0);
  var subesayisi = $('#inceleneceksahasayisi').val() //p

  if (iso9001) {
    // for (var i = 1; i <= subesayisi; i++) {
    //   anasube += parseFloat($('#iso9001hamsure' + i).val());
    //   indartsube += parseFloat($('#iso9001indart' + i).val());
    //   azartsube += parseFloat($('#iso9001azartsure' + i).val());
    //   entindartsube += parseFloat($('#iso9001entindart' + i).val());
    //   kalansube += parseFloat($('#iso9001kalansure' + i).val());
    //   a1suresube += parseFloat($('#iso9001a1sure' + i).val());
    //   a2suresube += parseFloat($('#iso9001a2sure' + i).val());
    //   gozsuresube += parseFloat($('#iso9001gsure' + i).val());
    //   ybsuresube += parseFloat($('#iso9001ybsure' + i).val());
    // }

    ana += parseFloat($('#iso9001hamsure').val());
    indart += parseFloat($('#iso9001indart').val());
    azart += parseFloat($('#iso9001azartsure').val());
    entindart += parseFloat($('#iso9001entindart').val());
    kalan += parseFloat($('#iso9001kalansure').val());
    a1sure += parseFloat($('#iso9001a1sure').val());
    a2sure += parseFloat($('#iso9001a2sure').val());
    gozsure += parseFloat($('#iso9001gsure').val());
    ybsure += parseFloat($('#iso9001ybsure').val());
  }

  if (iso14001) {
    ana += parseFloat($('#iso14001hamsure').val());
    indart += parseFloat($('#iso14001indart').val());
    azart += parseFloat($('#iso14001azartsure').val());
    entindart += parseFloat($('#iso14001entindart').val());
    kalan += parseFloat($('#iso14001kalansure').val());
    a1sure += parseFloat($('#iso14001a1sure').val());
    a2sure += parseFloat($('#iso14001a2sure').val());
    gozsure += parseFloat($('#iso14001gsure').val());
    ybsure += parseFloat($('#iso14001ybsure').val());
  }

  if (iso45001) {
    // for (var i = 1; i <= subesayisi; i++) {
    //   anasube += parseFloat($('#iso45001hamsure' + i).val());
    //   indartsube += parseFloat($('#iso45001indart' + i).val());
    //   azartsube += parseFloat($('#iso45001azartsure' + i).val());
    //   entindartsube += parseFloat($('#iso45001entindart' + i).val());
    //   kalansube += parseFloat($('#iso45001kalansure' + i).val());
    //   a1suresube += parseFloat($('#iso45001a1sure' + i).val());
    //   a2suresube += parseFloat($('#iso45001a2sure' + i).val());
    //   gozsuresube += parseFloat($('#iso45001gsure' + i).val());
    //   ybsuresube += parseFloat($('#iso45001ybsure' + i).val());
    // }
    ana += parseFloat($('#iso45001hamsure').val());
    indart += parseFloat($('#iso45001indart').val());
    azart += parseFloat($('#iso45001azartsure').val());
    entindart += parseFloat($('#iso45001entindart').val());
    kalan += parseFloat($('#iso45001kalansure').val());
    a1sure += parseFloat($('#iso45001a1sure').val());
    a2sure += parseFloat($('#iso45001a2sure').val());
    gozsure += parseFloat($('#iso45001gsure').val());
    ybsure += parseFloat($('#iso45001ybsure').val());
  }

  if (iso50001) {
    ana += parseFloat($('#iso50001hamsure').val());
    indart += parseFloat($('#iso50001indart').val());
    azart += parseFloat($('#iso50001azartsure').val());
    entindart += parseFloat($('#iso50001entindart').val());
    kalan += parseFloat($('#iso50001kalansure').val());
    a1sure += parseFloat($('#iso50001a1sure').val());
    a2sure += parseFloat($('#iso50001a2sure').val());
    gozsure += parseFloat($('#iso50001gsure').val());
    ybsure += parseFloat($('#iso50001ybsure').val());
  }

  if (iso27001) {
    ana += parseFloat($('#iso27001hamsure').val());
    indart += parseFloat($('#iso27001indart').val());
    azart += parseFloat($('#iso27001azartsure').val());
    entindart += parseFloat($('#iso27001entindart').val());
    kalan += parseFloat($('#iso27001kalansure').val());
    a1sure += parseFloat($('#iso27001a1sure').val());
    a2sure += parseFloat($('#iso27001a2sure').val());
    gozsure += parseFloat($('#iso27001gsure').val());
    ybsure += parseFloat($('#iso27001ybsure').val());
  }

  if (iso22000) {
    ana += parseFloat($('#iso22000hamsure').val());
    indart += parseFloat($('#iso22000indart').val());
    azart += parseFloat($('#iso22000azartsure').val());
    entindart += parseFloat($('#iso22000entindart').val());
    kalan += parseFloat($('#iso22000kalansure').val());
    a1sure += parseFloat($('#iso22000a1sure').val());
    a2sure += parseFloat($('#iso22000a2sure').val());
    gozsure += parseFloat($('#iso22000gsure').val());
    ybsure += parseFloat($('#iso22000ybsure').val());
  }

  if (isOicsmiic) {
    ana += parseFloat($('#oicsmiichamsure').val());
    indart += parseFloat($('#oicsmiicindart').val());
    azart += parseFloat($('#oicsmiicazartsure').val());
    entindart += parseFloat($('#oicsmiicentindart').val());
    kalan += parseFloat($('#oicsmiickalansure').val());
    a1sure += parseFloat($('#oicsmiica1sure').val());
    a2sure += parseFloat($('#oicsmiica2sure').val());
    gozsure += parseFloat($('#oicsmiicgsure').val());
    ybsure += parseFloat($('#oicsmiicybsure').val());
  }

  // kalan = (kalan);
  a1sure = parseFloat(roundNearest5(kalan * 30 / 100));
  a2sure = parseFloat(roundNearest5(kalan * 70 / 100));
  gozsure = parseFloat(roundNearest5(kalan / 3));
  ybsure = parseFloat(roundNearest5(kalan * 2 / 3));

  $('#toplamhamsure').val(ana.toFixed(1));
  $('#toplamindart').val(indart.toFixed(1));
  $('#toplamazart').val(azart.toFixed(1));
  $('#toplamentindart').val(entindart.toFixed(1));

  $('#toplamkalansure').val(kalan.toFixed(1));

  $('#toplama1sure').val(a1sure.toFixed(1));
  $('#toplama2sure').val(a2sure.toFixed(1));
  $('#toplamgsure').val(gozsure.toFixed(1));
  $('#toplamybsure').val(ybsure.toFixed(1));

  $('#toplamhamsuretmp').val(ana.toFixed(1));
  $('#toplamindarttmp').val(indart.toFixed(1));
  $('#toplamazarttmp').val(azart.toFixed(1));
  $('#toplamentindarttmp').val(entindart.toFixed(1));

  $('#toplamkalansuretmp').val(kalan.toFixed(1));

  $('#toplama1suretmp').val(a1sure.toFixed(1));
  $('#toplama2suretmp').val(a2sure.toFixed(1));
  $('#toplamgsuretmp').val(gozsure.toFixed(1));
  $('#toplamybsuretmp').val(ybsure.toFixed(1));

  $('#sureHesaplaSpinner').hide();

  denetimUcretiHesapla();
}

function denetimUcretiHesapla() {
  var iso9001 = $('#iso900115varyok').val() === '1',
    iso14001 = $('#iso1400115varyok').val() === '1',
    iso22000 = $('#iso2200018varyok').val() === '1',
    iso45001 = $('#iso4500118varyok').val() === '1',
    iso50001 = $('#iso5000118varyok').val() === '1',
    iso27001 = $('#iso27001varyok').val() === '1',
    oicsmiik = $('#helalvaryok').val() === '1',
    oicsmiik6 = $('#oicsmiik6varyok').val() === '1',
    oicsmiik9 = $('#oicsmiik9varyok').val() === '1',
    oicsmiik171 = $('#oicsmiik171varyok').val() === '1',
    oicsmiik23 = $('#oicsmiik23varyok').val() === '1',
    oicsmiik24 = $('#oicsmiik24varyok').val() === '1',
    oicSmiic = (oicsmiik || oicsmiik6 || oicsmiik9 || oicsmiik171 || oicsmiik23 || oicsmiik24) ?? false;

  var denetimsuresi = parseFloat($('#toplamkalansure').val());
  var oicdenetimsuresi = parseFloat(0);
  var kalan9001 = parseFloat(0);
  var kalan14001 = parseFloat(0);
  var kalan22000 = parseFloat(0);
  var kalanOicsmiic = parseFloat(0);
  var kalan45001 = parseFloat(0);
  var kalan50001 = parseFloat(0);
  var kalan27001 = parseFloat(0);

  var basvuruucreti = parseFloat(3000);
  var kullanimucreti = parseFloat(1000);
  var gunlukucret = parseFloat(1750);
  var gozgunlukucret = parseFloat(1000);

  var oicbasvuruucreti = (oicsmiik9) ? parseFloat(15000) : parseFloat(10000);
  var oickullanimucreti = parseFloat(2000);
  var oicgunlukucret = parseFloat(1000);

  var kacsistem = parseFloat(0);
  var toplamdenetimucreti = parseFloat(0);
  var toplamgozetimucreti = parseFloat(0);

  var oickacsistem = parseFloat(0);
  var oictoplamdenetimucreti = parseFloat(0);
  var oictoplamgozetimucreti = parseFloat(0);

  if (iso9001) {
    kalan9001 = parseFloat($('#iso9001kalansure').val());
    kacsistem++;
  }
  if (iso14001) {
    kalan14001 = parseFloat($('#iso14001kalansure').val());
    kacsistem++;
  }
  if (iso45001) {
    kalan45001 = parseFloat($('#iso45001kalansure').val());
    kacsistem++;
  }
  if (iso50001) {
    kalan50001 = parseFloat($('#iso50001kalansure').val());
    kacsistem++;
  }
  if (iso27001) {
    kalan27001 = parseFloat($('#iso27001kalansure').val());
    kacsistem++;
  }
  if (iso22000) {
    kalan22000 = parseFloat($('#iso22000kalansure').val());
    kacsistem++;
  }
  if (oicSmiic) {
    kalanOicsmiic = parseFloat($('#oicsmiickalansure').val());
    oickacsistem++;
  }
  var oicgozetimsuresi = (oicSmiic) ? parseFloat($('#oicsmiicgsure').val()).toFixed(1) : parseFloat(0);
  var isogozetimsuresi = (parseFloat($('#toplamgsure').val()) - oicgozetimsuresi).toFixed(1);

  basvuruucreti = basvuruucreti * kacsistem;
  denetimsuresi = denetimsuresi - (kalanOicsmiic);

  oicbasvuruucreti = oicbasvuruucreti * oickacsistem;
  oicdenetimsuresi = kalanOicsmiic;
  // console.log(kacsistem);
  // console.log("denetimUcretiHesapla:::kullanimucreti:::" + kullanimucreti + ":::basvuruucreti:::" + basvuruucreti + ":::isogozetimsuresi:::" + isogozetimsuresi + ":::oicgozetimsuresi:::" + oicgozetimsuresi + ":::gunlukucret:::" + gunlukucret);

  toplamdenetimucreti = basvuruucreti + (denetimsuresi * gunlukucret);
  toplamgozetimucreti = kullanimucreti + basvuruucreti + (isogozetimsuresi * gozgunlukucret);

  $('#belgelendirmedenetimucreti').val(toplamdenetimucreti.toFixed(0));
  $('#gozetimdenetimucreti').val(toplamgozetimucreti.toFixed(0));

  oictoplamdenetimucreti = oicbasvuruucreti + (oicdenetimsuresi * oicgunlukucret);
  oictoplamgozetimucreti = oickullanimucreti + oicbasvuruucreti + (oicgozetimsuresi * oicgunlukucret);

  $('#oicbelgelendirmedenetimucreti').val(oictoplamdenetimucreti.toFixed(0));
  $('#oicgozetimdenetimucreti').val(oictoplamgozetimucreti.toFixed(0));

}

function indirArttirSebepler() {
  var nedentmp = "";
  var entnedentmp = "";
  var neden = [], nedenler = [];

  var form = document.getElementById('write9001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart9001')) {
      if (form.elements[i].checked === true) {
        nedentmp = $('label[for="' + form.elements[i].id + '"]').html().replace("(-10)", "").replace("(+10)", "").replace("(-)", "").trim();
        nedentmp = nedentmp.replace("(-10)", "").replace("(+10)", "").replace("(10)", "").replace("(-30)", "").replace("(-)", "").trim();
        // console.log("9001:::"+nedentmp);
        if(nedentmp === "") continue;
        if (neden.length < 0) {
          neden.push(nedentmp);
        } else {
          if (neden.indexOf(nedentmp) === -1) {
            neden.push(nedentmp);
          }
        }
      }
    }
  }

  form = document.getElementById('write14001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart14001')) {
      if (form.elements[i].checked === true) {
        nedentmp = $('label[for="' + form.elements[i].id + '"]').html().replace("(-10)", "").replace("(+10)", "").replace("(-)", "").trim();
        nedentmp = nedentmp.replace("(-10)", "").replace("(+10)", "").replace("(10)", "").replace("(-30)", "").replace("(-)", "").trim();
        // console.log("14001:::"+nedentmp);
        if(nedentmp === "") continue;
        if (neden.length < 0) {
          neden.push(nedentmp);
        } else {
          if (neden.indexOf(nedentmp) === -1) {
            neden.push(nedentmp);
          }
        }
      }
    }
  }

  form = document.getElementById('write45001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart45001')) {
      if (form.elements[i].checked === true) {
        nedentmp = $('label[for="' + form.elements[i].id + '"]').html().replace("(-10)", "").replace("(+10)", "").replace("(-)", "").trim();
        nedentmp = nedentmp.replace("(-10)", "").replace("(+10)", "").replace("(10)", "").replace("(-30)", "").replace("(-)", "").trim();
        // console.log("45001:::"+nedentmp);
        if(nedentmp === "") continue;
        if (neden.length < 0) {
          neden.push(nedentmp);
        } else {
          if (neden.indexOf(nedentmp) === -1) {
            neden.push(nedentmp);
          }
        }
      }
    }
  }

  form = document.getElementById('write50001IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart50001')) {
      if (form.elements[i].checked === true) {
        nedentmp = $('label[for="' + form.elements[i].id + '"]').html().replace("(-10)", "").replace("(+10)", "").replace("(-)", "").trim();
        nedentmp = nedentmp.replace("(-10)", "").replace("(+10)", "").replace("(10)", "").replace("(-30)", "").replace("(-)", "").trim();
        // console.log("50001:::"+nedentmp);
        if(nedentmp === "") continue;

        if (neden.length < 0) {
          neden.push(nedentmp);
        } else {
          if (neden.indexOf(nedentmp) === -1) {
            neden.push(nedentmp);
          }
        }
      }
    }
  }

  form = document.getElementById('write22000IndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indart22000')) {
      if (form.elements[i].checked === true) {
        nedentmp = $('label[for="' + form.elements[i].id + '"]').html().replace("(-10)", "").replace("(+10)", "").replace("(-)", "").trim();
        nedentmp = nedentmp.replace("(-10)", "").replace("(+10)", "").replace("(10)", "").replace("(-30)", "").replace("(-)", "").trim();
        // console.log("22000:::"+nedentmp);
        if(nedentmp === "") continue;
        if (neden.length < 0) {
          neden.push(nedentmp);
        } else {
          if (neden.indexOf(nedentmp) === -1) {
            neden.push(nedentmp);
          }
        }
      }
    }
  }

  form = document.getElementById('writeSmiicIndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indartsmiic')) {
      if (form.elements[i].checked === true) {
        nedentmp = $('label[for="' + form.elements[i].id + '"]').html().replace("(-10)", "").replace("(+10)", "").replace("(-)", "").trim();
        nedentmp = nedentmp.replace("(-10)", "").replace("(+10)", "").replace("(10)", "").replace("(-30)", "").replace("(-)", "").trim();
        // console.log("smiic:::"+nedentmp);
        if(nedentmp === "") continue;
        if (neden.length < 0) {
          neden.push(nedentmp);
        } else {
          if (neden.indexOf(nedentmp) === -1) {
            neden.push(nedentmp);
          }
        }
      }
    }
  }

  form = document.getElementById('writeEntegreIndArt-form');
  for (var i = 0; i < form.length; i++) {
    if (form.elements[i].type === 'checkbox' && form.elements[i].name.startsWith('chb_indartentegre')) {
      if (form.elements[i].checked === true) {
        entnedentmp = "Entegre denetim";

        if (neden.length < 0) {
          neden.push(entnedentmp);
        } else {
          if (neden.indexOf(entnedentmp) === -1) {
            neden.push(entnedentmp);
          }
        }
      }
    }
  }

  neden.forEach(function(n) {
    // console.log("forEach:::: " + n);
    if(n.trim() !== "" || n.trim() !== null || !n.isNull()) nedenler.push(n);
  });
  // if (neden === "")
  //   neden = entneden;
  // else
  //   neden += entneden;

  // neden = neden.toString().substring(0, neden.toString().length - 2)

  $("#indartneden").val(nedenler);
  // console.log("indirim/arttırım sebepleri: " + nedenler);
}

function changeCalendarMonth(donem) {
  if ($("#divdenetimtakvimi").length > 0) {
    var datastring = "";
    var ay = $("#curmonth").html();
    var yil = $("#curyear").html();
    var m = parseInt(ay);
    var y = parseInt(yil);

    console.log(ay + " : " + yil);
    if (donem === "prev") {
      m--;
      // y--;

      if (m < 1) y--;
      if (m < 1) m = 12;

      datastring = "ay=" + m + "&yil=" + y;
      $("#curmonth").html(m);
      $("#curyear").html(y);
      console.log(m + " : " + y);
    }
    if (donem === "next") {
      m++;
      // y++;

      if (m > 12) y++;
      if (m > 12) m = 1;

      datastring = "ay=" + m + "&yil=" + y;
      $("#curmonth").html(m);
      $("#curyear").html(y);
      console.log(m + " : " + y);
    }
    if (donem === "current") {
      m = d.getMonth() + 1;
      y = d.getFullYear();

      datastring = "ay=" + m + "&yil=" + y;
      $("#curmonth").html(m);
      $("#curyear").html(y);
      console.log(m + " : " + y);
    }
    console.log("datastring: " + datastring);
    $.ajax({
      type: "GET",
      url: denetimTakvimiRoutePath,
      data: datastring,
      cache: false,
      success: function (html) {
        $("#divdenetimtakvimi").html(html);

        //console.log("Ay: "+ay);
        $("#divcalendarmonth").html(m + "." + y);
      }
    });
  }
}

function denetimTakvimiGoster() {
  if ($("#divdenetimtakvimi").length > 0) {
    var ay = $("#curmonth").html();
    var yil = $("#curyear").html();
    var datastring = "ay=" + ay + "&yil=" + yil;
    // console.log("denetimTakvimiGoster: "+datastring);
    $.ajax({
      type: "GET",
      url: denetimTakvimiRoutePath,
      data: datastring,
      cache: false,
      success: function (html) {
        $("#divdenetimtakvimi").html(html);
      }
    });
  }
}

function denetimSetiHazirla() {
  var form = $('#planlama-form');
  var disabled = form.find(':input:disabled').removeAttr('disabled');

  var postData = form.serialize();
  var formURL = $('#formPlanlamaRoute').val();
  $('#setSetHazirlaSpinner').show();
  // console.log("formKaydet::route:: ");
  // console.log("iso9001SureHesapla::postData:: " + formURL + "?" + postData + " ::::: " + iso900115varyok);
  $.ajax({
    url: formURL,
    type: 'POST',
    data: postData,
    success: function(html) {
      $('#btnAsRaporYazdirLink').html(html);
      disabled.attr('disabled', 'disabled');
      $('#setSetHazirlaSpinner').hide();

    },
    error: function(jqXHR, textStatus, errorThrown) {
      $('#formkaydetsonucerror').html('[iso9001SureHesapla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown + '<br>formKaydet: ' + formURL + '?' + postData);
      // window.console.log("formKaydet: " + formURL + "?" + postData);
      $('#myModalError').modal('show');
      $('#setSetHazirlaSpinner').hide();
    }
  });
}

function kararHazirla() {
  var form = $('#karar-form');

  var postData = form.serialize();
  var formURL = $('#formKararRoute').val();
  console.log("Karar hazırla: " + postData);
  $.ajax(
    {
      url: formURL,
      type: 'POST',
      data: postData,
      success: function (html) {
        $("#btnAsRaporYazdirLink").html(html);
        $("#dvloader").hide();
      },
      error: function (jqXHR, textStatus, errorThrown) {
        $("#btnAsRaporYazdirLink").html('[kararHazirla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown);
        $("#dvloader").hide();
      }
    });
}

function sertifikaKaydet() {
  var form = $('#sertifika-form');

  var postData = form.serialize();
  var formURL = $('#formSertifikaKaydetRoute').val();
  console.log("sertifika-form kaydet: " + postData);
  $.ajax(
    {
      url: formURL,
      type: 'POST',
      data: postData,
      success: function (html) {
        $("#btnAsRaporKaydetLink").html(html);
        $("#dvloader").hide();
      },
      error: function (jqXHR, textStatus, errorThrown) {
        $("#btnAsRaporKaydetLink").html('[sertifikaKaydet]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown);
        $("#dvloader").hide();
      }
    });
}

function sertifikaHazirla() {
  var form = $('#sertifika-form');
  var formWrite9001IndArt = $('#write9001IndArt-form');
  var formWrite14001IndArt = $('#write14001IndArt-form');
  var formWrite45001IndArt = $('#write45001IndArt-form');

  var postData = form.serialize() + "&" + formWrite9001IndArt.serialize() + "&" + formWrite14001IndArt.serialize() + "&" + formWrite45001IndArt.serialize();
  var formURL = $('#formSertifikaRoute').val();
  console.log("sertifika-form hazırla: " + postData);
  $.ajax(
    {
      url: formURL,
      type: 'POST',
      data: postData,
      success: function (html) {
        $("#btnAsRaporYazdirLink").html(html);
        $("#dvloader").hide();
      },
      error: function (jqXHR, textStatus, errorThrown) {
        $("#btnAsRaporYazdirLink").html('[sertifikaHazirla]<br>Durum: ' + textStatus + '<br>Hata: ' + errorThrown);
        $("#dvloader").hide();
      }
    });
}

function subeSurelerEkle(alan, sube){
  // Retrieve default total values from data attributes or define them directly
  var defaultAna = parseFloat($('#toplamhamsuretmp').val()) || 0;
  var defaultIndart = parseFloat($('#toplamindarttmp').val()) || 0;
  var defaultAzart = parseFloat($('#toplamazarttmp').val()) || 0;
  var defaultEntindart = parseFloat($('#toplamentindarttmp').val()) || 0;
  var defaultKalan = parseFloat($('#toplamkalansuretmp').val()) || 0;

  // Initialize totals with default values
  var ana = defaultAna;
  var indart = defaultIndart;
  var azart = defaultAzart;
  var entindart = defaultEntindart;
  var kalan = defaultKalan;

  // Initialize other variables
  var a1sure = 0;
  var a2sure = 0;
  var gozsure = 0;
  var ybsure = 0;

  // Subtotal variables
  var anasube = 0;
  var indartsube = 0;
  var azartsube = 0;
  var entindartsube = 0;
  var kalansube = 0;
  var a1suresube = 0;
  var a2suresube = 0;
  var gozsuresube = 0;
  var ybsuresube = 0;
  var subesayisi = $('#inceleneceksahasayisi').val();

  for (var i = 1; i <= subesayisi; i++) {
    var chk = $('#chkSube' + i + alan).is(':checked');
    if (chk) {
      // Accumulate subtotals from checked checkboxes
      anasube += parseFloat($('#' + alan + 'hamsure' + i).val()) || 0;
      indartsube += parseFloat($('#' + alan + 'indart' + i).val()) || 0;
      azartsube += parseFloat($('#' + alan + 'azartsure' + i).val()) || 0;
      entindartsube += parseFloat($('#' + alan + 'entindart' + i).val()) || 0;
      kalansube += parseFloat($('#' + alan + 'kalansure' + i).val()) || 0;
      a1suresube += parseFloat($('#' + alan + 'a1sure' + i).val()) || 0;
      a2suresube += parseFloat($('#' + alan + 'a2sure' + i).val()) || 0;
      gozsuresube += parseFloat($('#' + alan + 'gsure' + i).val()) || 0;
      ybsuresube += parseFloat($('#' + alan + 'ybsure' + i).val()) || 0;
    }
  }

  // Add subtotals to the default totals
  ana += anasube;
  indart += indartsube;
  azart += azartsube;
  entindart += entindartsube;
  kalan += kalansube;

  // Calculate other totals based on the updated 'kalan'
  a1sure = parseFloat(roundNearest5(kalan * 30 / 100));
  a2sure = parseFloat(roundNearest5(kalan * 70 / 100));
  gozsure = parseFloat(roundNearest5(kalan / 3));
  ybsure = parseFloat(roundNearest5(kalan * 2 / 3));

  // Update the total input fields
  $('#toplamhamsure').val(ana.toFixed(1));
  $('#toplamindart').val(indart.toFixed(1));
  $('#toplamazart').val(azart.toFixed(1));
  $('#toplamentindart').val(entindart.toFixed(1));
  $('#toplamkalansure').val(kalan.toFixed(1));

  $('#toplama1sure').val(a1sure.toFixed(1));
  $('#toplama2sure').val(a2sure.toFixed(1));
  $('#toplamgsure').val(gozsure.toFixed(1));
  $('#toplamybsure').val(ybsure.toFixed(1));

  $('#sureHesaplaSpinner').hide();

  denetimUcretiHesapla();
}

