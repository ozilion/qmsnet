/**
 * Form Picker
 */

'use strict';

(function () {
  // Flat Picker
  // --------------------------------------------------------------------
  const bggtarihi = document.querySelector('#gozdengecirmetarihi'),
    tarihrevasama1 = document.querySelector('#tarihrevasama1'),
    asama1tar = document.querySelector('#asama1tar'),
    tarihrevasama2 = document.querySelector('#tarihrevasama2'),
    asama2tar = document.querySelector('#asama2tar'),
    tarihrevgozetim1 = document.querySelector('#tarihrevgozetim1'),
    gozetim1tar = document.querySelector('#gozetim1tar'),
    tarihrevgozetim2 = document.querySelector('#tarihrevgozetim2'),
    gozetim2tar = document.querySelector('#gozetim2tar'),
    tarihrevyb = document.querySelector('#tarihrevyb'),
    ybtar = document.querySelector('#ybtar'),
    degerlendirmekarartarih = document.querySelector('#degerlendirmekarartarih'),
    ilkyayin = document.querySelector('#ilkyayin'),
    yayintarihi = document.querySelector('#yayintarihi'),
    gecerliliktarihi = document.querySelector('#gecerliliktarihi'),
    bitistarihi = document.querySelector('#bitistarihi'),
    selectPicker = $('.selectpicker');

  // bggtarihi
  if (bggtarihi) {
    bggtarihi.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (tarihrevasama1) {
    tarihrevasama1.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (asama1tar) {
    asama1tar.flatpickr({
      mode: 'multiple',
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (tarihrevasama2) {
    tarihrevasama2.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (asama2tar) {
    asama2tar.flatpickr({
      mode: 'multiple',
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (tarihrevgozetim1) {
    tarihrevgozetim1.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (gozetim1tar) {
    gozetim1tar.flatpickr({
      mode: 'multiple',
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (tarihrevgozetim2) {
    tarihrevgozetim2.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (gozetim2tar) {
    gozetim2tar.flatpickr({
      mode: 'multiple',
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (tarihrevyb) {
    tarihrevyb.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (ybtar) {
    ybtar.flatpickr({
      mode: 'multiple',
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (degerlendirmekarartarih) {
    degerlendirmekarartarih.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (ilkyayin) {
    ilkyayin.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (yayintarihi) {
    yayintarihi.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (gecerliliktarihi) {
    gecerliliktarihi.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }
  if (bitistarihi) {
    bitistarihi.flatpickr({
      dateFormat: 'd.m.Y',
      monthSelectorType: 'static'
    });
  }

  // Bootstrap Select
  // --------------------------------------------------------------------
  if (selectPicker.length) {
    selectPicker.selectpicker();
    handleBootstrapSelectEvents();
  }


})();


function chatgptForm() {

  const prompt = $('#prompt').val();
  const formURL = $('#chatgptFormRoute').val();
  const errorElement = $('#error');
  const outputElement = $('#responseOutput');
  var postData = 'prompt=' + prompt;

  // Hata mesajını ve önceki yanıtı temizle
  errorElement.hide().text('');
  outputElement.text('');

  if (!prompt) {
    errorElement.text('Prompt alanı zorunludur!').show();
    return;
  }

  $.ajax({
    url: formURL,
    type: 'POST',
    data: postData,
    success: function (response) {
      outputElement.text(response.output || 'Yanıt bulunamadı.');
    },
    error: function (xhr) {
      errorElement.text('Bir hata oluştu. Lütfen tekrar deneyin.').show();
      console.error(xhr.responseText);
    }
  });
}

function geminiForm() {

  const prompt = $('#geminiprompt').val();
  const formURL = $('#geminiFormRoute').val();
  const errorElement = $('#geminierror');
  const outputElement = $('#geminiresponseOutput');
  var postData = 'prompt=' + prompt;

  // Hata mesajını ve önceki yanıtı temizle
  errorElement.hide().text('');
  outputElement.text('');

  if (!prompt) {
    errorElement.text('Prompt alanı zorunludur!').show();
    return;
  }

  $.ajax({
    url: '/gemini/price/BTCUSD',
    type: 'GET',
    success: function (response) {
      if (response.success) {
        outputElement.text(response.data || 'Yanıt bulunamadı.');
        console.log('Price Data:', response.data);
      } else {
        console.error('Error:', response.message);
      }
    },
    error: function (xhr) {
      console.error('API Error:', xhr.responseText);
    }
  });

}
