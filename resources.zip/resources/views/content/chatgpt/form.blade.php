@php use Illuminate\Support\Facades\DB; @endphp
@extends('layouts.layoutMaster')

@section('title', 'ChatGPT Api Test')


@section('vendor-style')
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css')}}"/>
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')}}"/>
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-select-bs5/select.bootstrap5.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-fixedcolumns-bs5/fixedcolumns.bootstrap5.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-fixedheader-bs5/fixedheader.bootstrap5.css')}}">
@endsection

@section('page-style')
  <!-- Page -->
  <link rel="stylesheet" href="{{asset('assets/vendor/css/pages/cards-statistics.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/css/pages/cards-analytics.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')}}">
  <link rel="stylesheet" href="{{asset('assets/vendor/css/style.css')}}">
@endsection

@section('vendor-script')
  <script src="{{asset('assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.colVis.min.js"></script>
@endsection

@section('page-script')
  <script src="{{asset('assets/js/forms-qmsnet.js')}}"></script>
@endsection

@section('content')
  <div class="row gy-4 mb-4">
    <div class="col-xl-12">
      <!-- Fixed Header -->
      <div class="card">
        <div class="card-datatable table-responsive-sm pt-0 text-wrap">
          <form id="chatgptForm" onSubmit="return false">
            {{ csrf_field() }}
            <input type="hidden" id="chatgptFormRoute" value="{{route('chatgptFORM')}}">
            <textarea class="form-control h-px-100" id="prompt" name="prompt" placeholder="Bir şeyler yazın...">{{ old('prompt', $prompt ?? '') }}</textarea>
            <label for="prompt">Prompt:</label><br>
            <p id="error" style="color: red; display: none;"></p>
            <br>
            <button type="button" class="btn btn-sm btn-success" onclick="chatgptForm()">Gönder</button>
          </form>

          <hr>

          <h2>API Yanıtı:</h2>
          <div id="responseOutput" style="white-space: pre-wrap;"></div>

        </div>
      </div>
    </div>
  </div>
  <div class="row gy-4 mb-4">
    <div class="col-xl-12">
      <!-- Fixed Header -->
      <div class="card">
        <div class="card-datatable table-responsive-sm pt-0 text-wrap">
          <form id="geminiForm" onSubmit="return false">
            {{ csrf_field() }}
{{--            <input type="hidden" id="geminiFormRoute" value="{{route('geminiFORM')}}">--}}
            <textarea class="form-control h-px-100" id="geminiprompt" name="geminiprompt" placeholder="Bir şeyler yazın...">{{ old('geminiprompt', $geminiprompt ?? '') }}</textarea>
            <label for="geminiprompt">Prompt:</label><br>
            <p id="geminierror" style="color: red; display: none;"></p>
            <br>
            <button type="button" class="btn btn-sm btn-success" onclick="geminiForm()">Gönder</button>
          </form>

          <hr>

          <h2>API Yanıtı:</h2>
          <div id="geminiresponseOutput" style="white-space: pre-wrap;"></div>

        </div>
      </div>
    </div>
  </div>

@endsection
